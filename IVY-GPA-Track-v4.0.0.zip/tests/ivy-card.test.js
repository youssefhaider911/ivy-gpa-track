"use strict";
const fs = require("fs");
const vm = require("vm");
const { h, makeDocument, getComputedStyle } = require("./mockdom");
const src = fs.readFileSync(require("path").join(__dirname, "..", "ivyParser.js"), "utf8");
const doc = makeDocument(h("body", {},
  h("main", {},
    h("div", { class: "MuiCard-root" },
      h("div", {}, "Name: Overall"),
      h("div", {}, "Max: 100"),
      h("div", {}, "Score:79.73")
    )
  )
));
const ctx = { document: doc, location: { href: "https://lms.ivyis.org/courses/6130/gradingitemslist" }, getComputedStyle, URL, console };
ctx.window = ctx;
vm.createContext(ctx);
vm.runInContext(src, ctx, { filename: "ivyParser.js" });
const out = ctx.IvyParser.parse();
const matches = out.courseLevel.filter(x => x.label === "Overall" && x.score === 79.73 && x.max === 100 && x.percentage === 79.7);
if (matches.length !== 1) throw new Error("Expected exactly one Overall card grade, got " + JSON.stringify(out.courseLevel));
if (out.diagnostics.parserId !== "ivy-gradebook") throw new Error("Wrong parser id");
console.log("PASS Ivy screenshot-style card: Overall 79.73/100 parsed exactly once");
