"use strict";
const fs = require("fs"); const vm = require("vm"); const path = require("path");
const { h, makeDocument, getComputedStyle } = require("./mockdom");
const src = fs.readFileSync(path.join(__dirname,"..","ivyParser.js"),"utf8");
const doc = makeDocument(h("body",{}, h("div",{}, h("div",{}, "Name: Overall"), h("div",{}, "Max: 100"), h("div",{}, "Score:79.73"))));
// Force browser-like textContent concatenation with no CSS whitespace between block children.
function rawText(el){ if(el.nodeType===3) return el.nodeValue||""; let s=""; for(const c of el.childNodes||[]) s+=rawText(c); return s; }
for(const el of [doc.body,...doc.body.querySelectorAll("div")]) Object.defineProperty(el,"textContent",{configurable:true,get(){return rawText(this)}});
const ctx={document:doc,location:{href:"https://lms.ivyis.org/courses/6130/gradingitemslist",hostname:"lms.ivyis.org"},getComputedStyle,URL,console}; ctx.window=ctx; vm.createContext(ctx); vm.runInContext(src,ctx);
const out=ctx.IvyParser.parse(); const m=out.courseLevel.filter(x=>x.label==="Overall"&&x.score===79.73&&x.max===100&&x.percentage===79.7);
if(m.length!==1) throw new Error("Expected 1 Overall grade, got "+JSON.stringify(out.courseLevel)); console.log("PASS no-whitespace DOM: Overall 79.73/100 parsed exactly once");
