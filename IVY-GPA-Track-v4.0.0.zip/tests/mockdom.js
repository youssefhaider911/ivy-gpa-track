"use strict";
// Minimal DOM used by the integration test (no external dependencies).
// Supports the selectors GradeDash uses: tag, .class, [attr], [attr="v"], [attr*="v"], [attr^="v"], comma lists.
// Descendant combinators are intentionally unsupported and throw, so selector drift is caught.

class TextNode {
  constructor(v) { this.nodeType = 3; this.nodeValue = String(v); this.parentNode = null; }
  get textContent() { return this.nodeValue; }
}

const cache = new Map();
function parseCompound(s) {
  s = s.trim();
  const r = { tag: null, classes: [], attrs: [] };
  const re = /^([a-zA-Z][a-zA-Z0-9]*)|\.([\w-]+)|\[([\w-]+)(?:([*^]?=)(?:"([^"]*)"|'([^']*)'|([^\]]*)))?\]/g;
  let m, pos = 0;
  while ((m = re.exec(s)) && m[0] !== "") {
    if (m.index !== pos) throw new Error("Unsupported selector: " + s);
    pos = re.lastIndex;
    if (m[1]) r.tag = m[1].toUpperCase();
    else if (m[2]) r.classes.push(m[2]);
    else r.attrs.push({ name: m[3], op: m[4] || null, val: m[5] != null ? m[5] : m[6] != null ? m[6] : m[7] });
  }
  if (pos !== s.length) throw new Error("Unsupported selector: " + s);
  return r;
}
function parseSel(sel) {
  if (!cache.has(sel)) cache.set(sel, sel.split(",").map(parseCompound));
  return cache.get(sel);
}
function matchCompound(el, r) {
  if (r.tag && el.tagName !== r.tag) return false;
  const cls = (el.attrs.class || "").split(/\s+/);
  for (const c of r.classes) if (cls.indexOf(c) === -1) return false;
  for (const a of r.attrs) {
    const v = el.getAttribute(a.name);
    if (v == null) return false;
    if (a.op === "=" && v !== a.val) return false;
    if (a.op === "*=" && v.indexOf(a.val) === -1) return false;
    if (a.op === "^=" && v.indexOf(a.val) !== 0) return false;
  }
  return true;
}

class El {
  constructor(tag, attrs) {
    this.nodeType = 1;
    this.tagName = tag.toUpperCase();
    this.attrs = {};
    this.style = {};
    this.childNodes = [];
    this.parentNode = null;
    this.onclick = null;
    Object.keys(attrs || {}).forEach(k => {
      const v = attrs[k];
      if (k === "onclick") this.onclick = v;
      else if (k === "hidden" && v) this.style.display = "none";
      else if (v === false || v == null) { /* omit */ }
      else this.attrs[k] = v === true ? "" : String(v);
    });
    this.disabled = this.attrs.disabled != null;
  }
  get children() { return this.childNodes.filter(n => n.nodeType === 1); }
  append(...kids) {
    kids.flat(Infinity).forEach(k => {
      if (k == null || k === false) return;
      const n = typeof k === "object" ? k : new TextNode(k);
      n.parentNode = this;
      this.childNodes.push(n);
    });
    return this;
  }
  getAttribute(n) { return Object.prototype.hasOwnProperty.call(this.attrs, n) ? this.attrs[n] : null; }
  setAttribute(n, v) { this.attrs[n] = String(v); }
  get textContent() { return this.childNodes.map(n => n.textContent).join(""); }
  get offsetParent() {
    for (let e = this; e && e.nodeType === 1; e = e.parentNode) if (e.style.display === "none") return null;
    return this.parentNode || {};
  }
  matches(sel) { return parseSel(sel).some(p => matchCompound(this, p)); }
  closest(sel) {
    for (let e = this; e && e.nodeType === 1; e = e.parentNode) if (e.matches(sel)) return e;
    return null;
  }
  querySelectorAll(sel) {
    const parts = parseSel(sel), out = [];
    const walk = n => n.children.forEach(c => { if (parts.some(p => matchCompound(c, p))) out.push(c); walk(c); });
    walk(this);
    return out;
  }
  querySelector(sel) { return this.querySelectorAll(sel)[0] || null; }
  click() { if (this.onclick && !this.disabled) this.onclick(); }
}

function h(tag, attrs, ...kids) { return new El(tag, attrs).append(...kids); }

function makeDocument(body) {
  const html = new El("html");
  const doc = {
    documentElement: html,
    get body() { return html.children[0]; },
    setBody(b) { html.childNodes = []; html.append(b); },
    querySelectorAll: s => html.querySelectorAll(s),
    querySelector: s => html.querySelector(s),
    createElement: t => new El(t)
  };
  doc.setBody(body);
  return doc;
}

function getComputedStyle(el) {
  return { display: el.style.display || "block", visibility: el.style.visibility || "visible", opacity: el.style.opacity != null ? el.style.opacity : "1" };
}

module.exports = { h, El, makeDocument, getComputedStyle };
