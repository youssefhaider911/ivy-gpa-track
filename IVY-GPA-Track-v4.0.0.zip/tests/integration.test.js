"use strict";
// End-to-end integration test for the production pipeline:
// Courses -> pagination -> ALL courses -> course page -> GradeBook -> ivy-gradebook -> extraction
// -> aggregation -> GPA -> alerts -> dashboard.
// Runs the REAL extension files (background.js, content.js, parsers.js, ivyParser.js, gpa.js, dashboard.js)
// against a simulated Ivy LMS with a mocked chrome.* API. Run with:  node tests/integration.test.js
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const { h, makeDocument, getComputedStyle } = require("./mockdom");

const ROOT = path.join(__dirname, "..");
const read = f => fs.readFileSync(path.join(ROOT, f), "utf8");
const ORIGIN = "https://lms.ivyis.org";

// ------------------------------------------------------------------ fake LMS data
const NAMES = ["Algebra 2", "English Language Arts", "Biology", "World History", "Physics", "Chemistry",
  "Art Studio", "Arabic Language", "French", "Geometry", "Music", "Physical Education",
  "Robotics Club", "Homeroom", "Library Skills", "Drama", "Chess Club", "Coding Lab",
  "Debate", "Career Guidance", "Yearbook", "Calculus"];
const PER_PAGE = 12; // known only to the fake site, never to the extension
const COURSES = NAMES.map((n, i) => ({ id: "C" + String(i + 1).padStart(2, "0"), name: n, total: 70 + (i * 7) % 29, quiz: 12 + (i % 9) }));
const EMPTY_ID = "C07", REDIRECT_ID = "C13", BROKEN_ID = "C18", LETTER_ID = "C02";

function chrome0() {
  return h("header", {}, h("a", { href: "/courses" }, "Courses"), h("a", { href: "/notifications" }, "Alerts", h("span", { class: "MuiBadge-badge" }, "5")),
    h("div", { class: "MuiAvatar-root" }, "JD"));
}

function coursesPage(state, rerender) {
  const pages = Math.ceil(COURSES.length / PER_PAGE);
  const list = COURSES.slice((state.page - 1) * PER_PAGE, state.page * PER_PAGE);
  const pageBtns = [];
  for (let p = 1; p <= pages; p++) {
    pageBtns.push(h("li", {}, h("button", { class: "MuiPaginationItem-root MuiPaginationItem-page", "aria-label": "page " + p, "aria-current": p === state.page ? "true" : false,
      onclick: () => { state.page = p; rerender(); } }, String(p))));
  }
  const last = state.page >= pages;
  return h("body", {}, chrome0(),
    h("main", {},
      h("h1", {}, "My Courses"),
      list.map(c => h("div", { class: "MuiCard-root" }, h("a", { href: "/courses/" + c.id }, c.name, h("span", { class: "MuiBadge-badge" }, "2")))),
      state.page === 2 ? h("aside", {}, h("h3", {}, "Recently viewed"), h("a", { href: ORIGIN + "/courses/" + COURSES[0].id }, COURSES[0].name)) : null,
      h("nav", { "aria-label": "pagination navigation" }, h("ul", {},
        h("li", {}, h("button", { "aria-label": "Go to previous page", disabled: state.page === 1, onclick: () => { state.page--; rerender(); } }, h("svg", {}))),
        pageBtns,
        h("li", {}, h("button", { "aria-label": "Go to next page", class: last ? "MuiPaginationItem-root Mui-disabled" : "MuiPaginationItem-root", disabled: last,
          onclick: () => { state.page++; rerender(); } }, h("svg", {})))))));
}

function coursePage(c) {
  return h("body", {}, chrome0(), h("main", {}, h("h1", {}, c.name),
    h("div", { role: "tablist" }, h("a", { href: "/courses/" + c.id + "/overview", role: "tab" }, "Overview"),
      h("a", { href: "/courses/" + c.id + "/gradingitemslist", role: "tab" }, "GradeBook"))));
}

function head() {
  return h("thead", {}, h("tr", {}, ["Item", "Category", "Weight", "Score", "Percentage", "Status"].map(t => h("th", {}, t))));
}
function row(cells, attrs) { return h("tr", attrs || {}, cells.map(c => h("td", {}, c))); }

function gradebookPage(c) {
  if (c.id === EMPTY_ID) {
    return h("body", {}, chrome0(), h("main", {}, h("h2", {}, "GradeBook"), h("table", { class: "MuiTable-root" }, head(), h("tbody", {})), h("p", {}, "No grading items found")));
  }
  if (c.id === BROKEN_ID) {
    return h("body", {}, chrome0(), h("main", {}, h("table", {}, h("tbody", {}, row(["1", "2", "3"]), row(["4", "5", "6"])))));
  }
  const quizPct = Math.round(c.quiz / 20 * 1000) / 10;
  return h("body", {}, chrome0(), h("main", {},
    h("h2", {}, "GradeBook"),
    c.id === LETTER_ID ? h("p", {}, h("span", {}, "Course Grade:"), " ", h("span", {}, "A-")) : null,
    h("div", { class: "MuiTableContainer-root" }, h("table", { class: "MuiTable-root" }, head(), h("tbody", {},
      row(["Quiz 1", "Quiz", "10%", c.quiz + "/20", quizPct + "%", h("span", { class: "MuiChip-root" }, "Graded")]),
      row(["Unit Test 1", "Test", "30%", "41/50", "82%", h("span", { class: "MuiChip-root" }, "Graded")]),
      row(["Homework 5", "Homework", "5%", "—", "—", h("span", { class: "MuiChip-root" }, "Not submitted")]),
      row([h("span", {}, "Project", h("span", { class: "MuiBadge-badge" }, "3")), "Project", "20%", "", "", "Pending"]),
      row(["Ghost item", "Quiz", "10%", "0/20", "0%", ""], { hidden: true }),
      row(["Old item", "Quiz", "10%", "1/1", "100%", ""], { "aria-hidden": "true" }),
      row(["Total", "", "", "", c.total + "%", ""])
    )))));
}

function loginPage() {
  return h("body", {}, h("h5", {}, "Hi, Welcome Back"), h("button", {}, "Continue with Microsoft"));
}

// ------------------------------------------------------------------ fake browser + chrome API
const fastTimeout = (f, ms) => setTimeout(f, Math.max(0, Math.round((ms || 0) / 100)));

function createBrowser(stats) {
  const tab = { id: 1, url: null, content: null, doc: null, loc: null };
  const updatedListeners = [];

  function locationFor(url) {
    const u = new URL(url, ORIGIN);
    return { origin: u.origin, hostname: u.hostname, pathname: u.pathname, search: u.search, get href() { return u.origin + this.pathname + this.search; } };
  }

  function load(url) {
    let u = new URL(url, ORIGIN);
    let p = u.pathname;
    const gb = p.match(/^\/courses\/([^/]+)\/gradingitemslist$/);
    if (gb && gb[1] === REDIRECT_ID) { u = new URL("/login", ORIGIN); p = "/login"; stats.redirects++; }
    const loc = locationFor(u.href);
    const state = { page: 1 };
    let doc;
    const cm = p.match(/^\/courses\/([^/]+)$/);
    if (p === "/courses") {
      doc = makeDocument(h("body", {}));
      const rerender = () => { doc.setBody(coursesPage(state, rerender)); loc.search = "?page=" + state.page; };
      rerender();
    } else if (gb) doc = makeDocument(gradebookPage(COURSES.find(c => c.id === gb[1])));
    else if (cm && COURSES.find(c => c.id === cm[1])) doc = makeDocument(coursePage(COURSES.find(c => c.id === cm[1])));
    else doc = makeDocument(loginPage());

    const ctx = { document: doc, location: loc, getComputedStyle, URL, console, setTimeout: fastTimeout, clearTimeout,
      chrome: { runtime: { onMessage: { addListener: fn => { ctx.__listener = fn; } } } } };
    ctx.window = ctx;
    vm.createContext(ctx);
    ["ivyParser.js", "parsers.js", "content.js"].forEach(f => vm.runInContext(read(f), ctx, { filename: f }));
    // Spies: count real invocations of each registered parser.
    ctx.GDParsers.registry.forEach(p => {
      const orig = p.parse;
      p.parse = function () { stats.parserCalls[p.id] = (stats.parserCalls[p.id] || 0) + 1; return orig.apply(this, arguments); };
    });
    tab.url = loc.href; tab.doc = doc; tab.loc = loc; tab.content = ctx;
    stats.navigations.push(p);
    setTimeout(() => updatedListeners.slice().forEach(fn => fn(tab.id, { status: "complete" })), 1);
  }

  const chrome = {
    tabs: {
      query: async () => [],
      create: async (o) => { load(o.url); return { id: tab.id }; },
      update: async (id, o) => { load(o.url); return { id: id }; },
      sendMessage: (id, msg) => new Promise((resolve, reject) => {
        if (!tab.content || !tab.content.__listener) return reject(new Error("no receiver"));
        tab.content.__listener(msg, {}, resolve);
      }),
      onUpdated: {
        addListener: fn => updatedListeners.push(fn),
        removeListener: fn => { const i = updatedListeners.indexOf(fn); if (i >= 0) updatedListeners.splice(i, 1); }
      }
    }
  };
  return { chrome, tab };
}

function createStorage() {
  const data = {};
  return {
    data,
    local: {
      get: async keys => {
        const ks = keys == null ? Object.keys(data) : Array.isArray(keys) ? keys : [keys];
        const out = {};
        ks.forEach(k => { if (data[k] !== undefined) out[k] = JSON.parse(JSON.stringify(data[k])); });
        return out;
      },
      set: async obj => { Object.keys(obj).forEach(k => { data[k] = JSON.parse(JSON.stringify(obj[k])); }); },
      remove: async ks => { [].concat(ks).forEach(k => delete data[k]); }
    }
  };
}

function loadBackground(browser, storage) {
  const ctx = { console, setTimeout: fastTimeout, clearTimeout, URL };
  ctx.globalThis = ctx;
  ctx.window = undefined;
  ctx.chrome = {
    tabs: browser.chrome.tabs,
    storage: storage,
    runtime: { sendMessage: () => Promise.resolve(), onMessage: { addListener: fn => { ctx.__bg = fn; } } }
  };
  vm.createContext(ctx);
  vm.runInContext(read("gpa.js"), ctx, { filename: "gpa.js" });
  vm.runInContext(read("background.js").replace(/^import\s+".*";/m, ""), ctx, { filename: "background.js" });
  return ctx;
}

function send(bg, msg) { return new Promise(res => bg.__bg(msg, {}, res)); }

async function renderDashboard(storage) {
  const els = {};
  const stub = id => els[id] || (els[id] = { id, style: {}, innerHTML: "", textContent: "", disabled: false, value: "", dataset: {}, addEventListener() {} });
  const ctx = {
    console, URL, setTimeout, setInterval: () => 0, alert() {},
    location: { hash: "" },
    document: {
      getElementById: stub,
      querySelectorAll: () => [],
      createElement: () => { let t = ""; return { set textContent(v) { t = String(v); }, get innerHTML() { return t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); } }; }
    },
    chrome: { storage, runtime: { sendMessage() {}, onMessage: { addListener() {} } }, tabs: { create() {} } }
  };
  ctx.window = ctx;
  ctx.window.addEventListener = () => {};
  vm.createContext(ctx);
  vm.runInContext(read("gpa.js"), ctx, { filename: "gpa.js" });
  vm.runInContext(read("dashboard.js"), ctx, { filename: "dashboard.js" });
  await new Promise(r => setTimeout(r, 60));
  return { main: stub("main").innerHTML, banner: stub("progress-banner").innerHTML, GD: ctx.GD };
}

// ------------------------------------------------------------------ assertions
const results = [];
function check(name, cond, detail) { results.push({ name, pass: !!cond, detail: cond ? undefined : detail }); }

async function run() {
  const stats = { parserCalls: {}, navigations: [], redirects: 0 };
  const browser = createBrowser(stats);
  const storage = createStorage();
  const bg = loadBackground(browser, storage);

  // ---- Scan 1
  const r1 = await send(bg, { type: "GD_START_SCAN" });
  const scan1 = storage.data.gdLastScan;
  if (!scan1) throw new Error("scan failed: " + JSON.stringify(r1) + " progress=" + JSON.stringify(storage.data.gdProgress) + " navs=" + JSON.stringify(stats.navigations.slice(0,10)));
  const expectedPages = Math.ceil(COURSES.length / PER_PAGE);
  check("scan returned ok", r1 && r1.ok, r1);
  check("all course pages visited dynamically", scan1.pagesVisited.length === expectedPages, scan1.pagesVisited);
  check("all courses discovered across pages", scan1.discovered === COURSES.length, scan1.discovered);
  check("duplicate course links removed", scan1.duplicatesRemoved >= 1, scan1.duplicatesRemoved);
  check("every discovered course has a scan record", COURSES.every(c => scan1.courses.some(x => x.id === c.id && x.state)), scan1.courses.map(c => c.id + ":" + c.state));
  check("every course page visited", COURSES.every(c => stats.navigations.indexOf("/courses/" + c.id) !== -1), stats.navigations);
  const st = id => scan1.courses.find(c => c.id === id).state;
  check("empty GradeBook -> SUCCESS_EMPTY", st(EMPTY_ID) === "SUCCESS_EMPTY", st(EMPTY_ID));
  check("login redirect -> FAILED_NAVIGATION", st(REDIRECT_ID) === "FAILED_NAVIGATION", st(REDIRECT_ID));
  check("unparseable GradeBook -> FAILED_PARSING (not success)", st(BROKEN_ID) === "FAILED_PARSING", st(BROKEN_ID));
  const okCourses = scan1.courses.filter(c => c.state === "SUCCESS");
  check("all other courses SUCCESS", okCourses.length === COURSES.length - 3, okCourses.length);
  check("counts: succeeded includes empty", scan1.succeeded === COURSES.length - 2 && scan1.failed === 2, { s: scan1.succeeded, f: scan1.failed });

  const parsed = scan1.courses.filter(c => c.diagnostics);
  check("ivy-gradebook selected for every GradeBook", parsed.every(c => c.diagnostics.parserSelection.selected === "ivy-gradebook"), parsed.map(c => c.parserTrace));
  check("ivy-gradebook invoked for every GradeBook", parsed.every(c => c.parserId === "ivy-gradebook" && c.diagnostics.parserId === "ivy-gradebook"));
  check("parser trace text", okCourses.every(c => c.parserTrace === "detected: ivy | matched: ivy | selected: ivy-gradebook | invoked: ivy-gradebook"), okCourses[0] && okCourses[0].parserTrace);
  check("generic parser never invoked", !stats.parserCalls.generic, stats.parserCalls);
  check("ivy parser invoked once per reachable GradeBook", stats.parserCalls["ivy-gradebook"] === COURSES.length - 1, stats.parserCalls);

  const alg = scan1.courses.find(c => c.id === "C01");
  const quiz = alg.items.find(i => i.name === "Quiz 1");
  check("score/max extracted", quiz && quiz.score === COURSES[0].quiz && quiz.max === 20, quiz);
  check("weight column (10%) not treated as a grade", quiz && quiz.percentage === Math.round(COURSES[0].quiz / 20 * 1000) / 10, quiz);
  check("category extracted", quiz && quiz.category === "Quiz", quiz);
  const hw = alg.items.find(i => i.name === "Homework 5");
  check("ungraded item preserved with null grade", hw && hw.graded === false && hw.score === null && hw.percentage === null, hw);
  const proj = alg.items.find(i => i.name === "Project");
  check("badge counter stripped from item name, item kept ungraded", proj && proj.graded === false, alg.items.map(i => i.name));
  check("hidden and aria-hidden rows ignored", !alg.items.some(i => i.name === "Ghost item" || i.name === "Old item"), alg.items.map(i => i.name));
  check("Total kept separate as course-level grade", !alg.items.some(i => /total/i.test(i.name)) && alg.courseLevel.some(t => t.label === "Total" && t.percentage === COURSES[0].total), alg.courseLevel);
  check("item count exact (2 graded + 2 ungraded)", alg.items.length === 4, alg.items);
  const lc = scan1.courses.find(c => c.id === LETTER_ID);
  check("page-level 'Course Grade' letter captured", lc.courseLevel.some(t => t.letter === "A-"), lc.courseLevel);
  check("diagnostics fields present", ["tableCount", "tablesScanned", "candidateRows", "acceptedRows", "gradeElementCount", "gradeSamples", "warnings", "errors", "strategy"].every(k => k in alg.diagnostics), Object.keys(alg.diagnostics));

  // ---- Parser selection guard: on an Ivy page that is not a GradeBook, generic must NOT be chosen.
  await browser.chrome.tabs.update(1, { url: ORIGIN + "/courses/C01" });
  const sel = browser.tab.content.GDParsers.select();
  check("generic cannot replace Ivy on unsupported Ivy routes", sel.parser === null && sel.trace.detected === "ivy" && !sel.trace.genericAllowed, sel.trace);

  // ---- GPA consumes extracted data
  const dash1 = await renderDashboard(storage);
  const settings = dash1.GD.mergeSettings({});
  const gpa = dash1.GD.computeGpa(scan1.courses, settings);
  const mainWithGrades = scan1.courses.filter(c => dash1.GD.courseClass(c, settings) === "main" && dash1.GD.coursePct(c) != null || (dash1.GD.courseClass(c, settings) === "main" && dash1.GD.courseLetter(c)));
  check("GPA computed from extracted grades", gpa && gpa.included === mainWithGrades.length && gpa.included > 0, gpa && gpa.included);
  check("LMS letter used for GPA when provided", gpa.rows.some(r => r.course.id === LETTER_ID && r.letter === "A-" && r.source === "LMS-provided letter"));
  check("dashboard lists every course", COURSES.every(c => dash1.main.indexOf(c.name) !== -1), COURSES.filter(c => dash1.main.indexOf(c.name) === -1).map(c => c.name));
  check("dashboard shows calculated GPA", dash1.main.indexOf(gpa.weighted.toFixed(2)) !== -1, gpa.weighted);
  ["GPA Calculator", "Target GPA", "Other Courses", "All Courses", "Trends", "Scan History", "Scan Details", "FAILED_NAVIGATION", "FAILED_PARSING", "SUCCESS_EMPTY", "GPA Alert", "not an official"].forEach(t =>
    check("dashboard shows '" + t + "'", dash1.main.indexOf(t) !== -1));
  check("dashboard top counts", /Discovered: <b>22/.test(dash1.banner) && /Failed: <b>2/.test(dash1.banner), dash1.banner);
  check("no previous scan message on first scan", dash1.main.indexOf("No previous scan available") !== -1);

  // ---- Scan 2: grade drop + trends
  COURSES[0].total -= 8;
  const r2 = await send(bg, { type: "GD_START_SCAN" });
  check("second scan ok", r2 && r2.ok, r2);
  const dash2 = await renderDashboard(storage);
  check("grade-drop alert raised", dash2.main.indexOf("Grade Drop") !== -1 && dash2.main.indexOf("Algebra 2") !== -1);
  check("GPA trend shown (previous vs current)", dash2.main.indexOf("Previous GPA") !== -1);
  check("scan history stored locally", storage.data.gdScanHistory.length === 2, storage.data.gdScanHistory.length);

  // ---- Retry failed only re-scans failed courses
  const navBefore = stats.navigations.length;
  const r3 = await send(bg, { type: "GD_RETRY_FAILED" });
  const retried = stats.navigations.slice(navBefore).filter(p => /^\/courses\/[^/]+$/.test(p));
  check("retry scans only failed courses", r3 && r3.ok && retried.length === 2 && retried.indexOf("/courses/" + REDIRECT_ID) !== -1, retried);
  check("retry keeps full course list", storage.data.gdLastScan.courses.length === COURSES.length);

  const failed = results.filter(r => !r.pass);
  return { total: results.length, passed: results.length - failed.length, failed: failed };
}

module.exports = { run };
if (require.main === module) {
  run().then(r => {
    results.forEach(x => console.log((x.pass ? "PASS " : "FAIL ") + x.name + (x.pass ? "" : "  -> " + JSON.stringify(x.detail))));
    console.log("\n" + r.passed + "/" + r.total + " checks passed");
    process.exitCode = r.failed.length ? 1 : 0;
  }).catch(e => { console.error(e); process.exitCode = 1; });
}
