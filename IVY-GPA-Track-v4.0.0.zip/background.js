import "./gpa.js";
const GDG = globalThis.GD;
const LMS = "https://lms.ivyis.org";
const GB_RE = /\/courses\/[^/]+\/gradingitemslist/;
const STATUS_OF = { SUCCESS: "ok", SUCCESS_EMPTY: "empty", FAILED_NAVIGATION: "failed", FAILED_PARSING: "failed", FAILED_OTHER: "failed", SKIPPED: "skipped" };

let running = false;
let cancelRequested = false;

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function getSettings() {
  const st = await chrome.storage.local.get("gdSettings");
  return GDG.mergeSettings(st.gdSettings || {});
}

async function setProgress(p) {
  await chrome.storage.local.set({ gdProgress: p });
  chrome.runtime.sendMessage({ type: "GD_PROGRESS", progress: p }).catch(() => {});
}

function waitForLoad(tabId) {
  return new Promise((resolve) => {
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(); }, 45000);
  });
}

async function getTab(startUrl) {
  const tabs = await chrome.tabs.query({ url: LMS + "/*" });
  if (tabs.length) return tabs[0];
  return chrome.tabs.create({ url: startUrl, active: false });
}

async function navigate(tabId, url) {
  await chrome.tabs.update(tabId, { url });
  await waitForLoad(tabId);
  await sleep(300);
}

async function sendToTab(tabId, msg, tries) {
  const n = tries || 12;
  for (let i = 0; i < n; i++) {
    try {
      const r = await chrome.tabs.sendMessage(tabId, msg);
      if (r) return r;
    } catch (e) { /* content script may not be ready yet */ }
    await sleep(700);
  }
  return null;
}

// ---------- DISCOVERY: walk every Courses page until there is no next page ----------
async function discoverCourses(tabId, startUrl) {
  await navigate(tabId, startUrl);
  let res = await sendToTab(tabId, { type: "GD_PARSE_COURSES" });
  if (!res || !res.ok || !res.courses || !res.courses.length) {
    await navigate(tabId, LMS + "/courses");
    res = await sendToTab(tabId, { type: "GD_PARSE_COURSES" });
  }
  if (!res || !res.ok || !res.courses || !res.courses.length) {
    return { ok: false, error: (res && res.error) || "Could not read the Courses page. Make sure you are logged in to the LMS." };
  }
  const pagesVisited = [res.pagination && res.pagination.current ? String(res.pagination.current) : "1"];
  let totalPages = (res.pagination && res.pagination.total) || null;
  const all = res.courses.map(c => Object.assign({ page: 1 }, c));
  const ids = new Set(all.map(c => c.id));
  let stuck = 0, guard = 0;
  while (res && res.ok && res.pagination && res.pagination.hasNext && !cancelRequested && guard < 500) {
    guard++;
    await setProgress({ phase: "discovering", discovered: ids.size, scanned: 0, succeeded: 0, failed: 0, current: "", step: "Opening next Courses page", coursePage: pagesVisited.length + 1, totalPages: totalPages });
    const nxt = await sendToTab(tabId, { type: "GD_NEXT_PAGE" });
    if (!nxt || !nxt.ok) break;
    res = await sendToTab(tabId, { type: "GD_PARSE_COURSES" });
    if (!res || !res.ok) break;
    const pageNo = pagesVisited.length + 1;
    let added = 0;
    res.courses.forEach(c => { all.push(Object.assign({ page: pageNo }, c)); if (!ids.has(c.id)) { ids.add(c.id); added++; } });
    pagesVisited.push(res.pagination && res.pagination.current ? String(res.pagination.current) : String(pageNo));
    if (res.pagination && res.pagination.total) totalPages = res.pagination.total;
    if (!added) { stuck++; if (stuck >= 2) break; } else stuck = 0;
  }
  const seen = new Set();
  const discovered = [];
  let duplicatesRemoved = 0;
  for (const c of all) {
    if (seen.has(c.id)) { duplicatesRemoved++; continue; }
    seen.add(c.id);
    const title = splitCourseTitle(c.name);
    discovered.push({ id: c.id, name: title.displayName, subject: title.subject, section: title.section, url: c.url, page: c.page });
  }
  return { ok: true, discovered, duplicatesRemoved, pagesVisited, totalPages: Math.max(totalPages || 0, pagesVisited.length) };
}

// Normalize Ivy titles such as "# Language Arts-10-STEM : Gr10-B" into explicit fields.
function splitCourseTitle(name) {
  const raw = String(name || "").replace(/^#\\s*/, "").replace(/\\s+/g, " ").trim();
  const m = raw.match(/^(.{2,100}?)\\s*:\\s*(.{1,80})$/);
  if (m) return { subject: m[1].trim(), section: m[2].trim(), displayName: m[1].trim() + " — " + m[2].trim() };
  return { subject: raw, section: "", displayName: raw };
}


function isQuarterRow(item) {
  return /^quarter\s+[1-4]$/i.test(String(item && item.name || '').trim());
}

// Keep GradeBook items isolated to the quarter being scanned. The LMS may
// expose multiple quarters on the same GradeBook page, so explicit quarter
// labels must match the selected quarter. Items without a quarter label are
// retained because the LMS may use them as quarter-neutral records.
function filterRecordToQuarter(record, quarter) {
  const q = Number(quarter || 1);
  const marker = new RegExp('\\b(?:quarter\\s*|q)'+q+'\\b', 'i');
  const keep = (item) => {
    const text = String((item && (item.name || item.label || item.category)) || '');
    return marker.test(text);
  };
  if (Array.isArray(record.items)) record.items = record.items.filter(keep);
  if (Array.isArray(record.courseLevel)) record.courseLevel = record.courseLevel.filter(keep);
  record.quarter = q;
  return record;
}

function isAssessmentItem(item) {
  if (!item || isQuarterRow(item)) return false;
  const text = String((item.category || '') + ' ' + (item.name || '')).toLowerCase().replace(/\s+/g, ' ').trim();
  if (/\b(participation|behavior|behaviour|conduct|class participation|attitude|discipline|engagement|effort|citizenship|portfolio)\b/.test(text)) return false;
  return /\b(quiz|quizzes|wka|h\.?\s*w\.?|homework|assignment|assignments|ext(?:ra)?|ext\s+ticket|worksheet|classwork|assessment|test|tests|exam|exams|quarter\s+exam|project|projects|lab|labs|essay|presentation|task|tasks|cba|oth)\b/.test(text);
}

function classifyTicket(name, category) {
  const text = String((category || '') + ' ' + (name || '')).toLowerCase().replace(/\s+/g, ' ').trim();
  if (/\b(participation|behavior|behaviour|conduct|class participation|attitude|discipline|engagement|effort|citizenship)\b/.test(text)) return 'participation_behavior';
  if (isAssessmentItem({name:name, category:category})) return 'assignment_assessment';
  return 'other';
}

function normalizeTicketItems(items) {
  return (items || []).map(function (it) {
    const out = Object.assign({}, it);
    out.categoryGroup = classifyTicket(out.name, out.category);
    // Only assessment rows use zero to mean "not started". Participation and
    // portfolio rows with zero are graded low scores, and quarter rows are not tickets.
    if (isAssessmentItem(out) && out.score != null && Number(out.score) === 0 && Number(out.max) > 0) {
      out.graded = true;
      out.missing = false;
      out.notStarted = true;
      out.missingReason = 'Zero score means not started';
    } else {
      out.missing = !out.graded;
      out.notStarted = false;
      if (!isAssessmentItem(out)) delete out.missingReason;
    }
    return out;
  });
}

function analyzeTickets(items) {
  const groups = { participation_behavior: { label: 'Participation & Behavior', graded: 0, sum: 0, count: 0, missing: 0 }, assignment_assessment: { label: 'Assignments & Assessments', graded: 0, sum: 0, count: 0, missing: 0 }, other: { label: 'Other', graded: 0, sum: 0, count: 0, missing: 0 } };
  (items || []).forEach(function (it) {
    if (isQuarterRow(it)) return;
    const g = groups[it.categoryGroup || classifyTicket(it.name, it.category)];
    if (it.graded && isAssessmentItem(it) && (Number(it.score) === 0 || Number(it.percentage) === 0)) { g.notStarted = (g.notStarted || 0) + 1; return; }
    if (it.missing) { g.missing++; return; }
    if (it.graded && it.percentage != null) { g.graded++; g.sum += Number(it.percentage); g.count++; }
  });
  Object.keys(groups).forEach(function (k) { groups[k].average = groups[k].count ? Math.round(groups[k].sum / groups[k].count * 10) / 10 : null; });
  return groups;
}

// ---------- ONE COURSE: course page -> GradeBook -> ivy-gradebook ----------
async function scanCourse(tabId, c, prog, activeQuarter) {
  const t0 = Date.now();
  const gbUrl = LMS + "/courses/" + c.id + "/gradingitemslist";
  const record = {
    id: c.id, name: c.name, url: c.url, page: c.page, gradebookUrl: gbUrl,
    subject: "", section: "", courseNameSource: "discovery",
    state: null, status: null, items: [], courseLevel: [],
    parserId: null, parserTrace: "", diagnostics: null, strategy: null,
    warnings: [], errors: [], error: null, note: null, timing: {}, scannedAt: null
  };
  const finish = (state, msg) => {
    record.state = state;
    record.status = STATUS_OF[state];
    if (msg) {
      if (state.indexOf("FAILED") === 0) { record.error = msg; record.errors.push(msg); }
      else record.note = msg;
    }
    record.timing.totalMs = Date.now() - t0;
    const titleParts = splitCourseTitle(record.name);
    record.subject = titleParts.subject;
    record.section = titleParts.section;
    record.displayName = titleParts.displayName;
    record.scannedAt = Date.now();
    return record;
  };
  try {
    await prog("Opening course");
    record.strategy = "course page -> GradeBook link";
    await navigate(tabId, c.url);
    await prog("Reading course name");
    const meta = await sendToTab(tabId, { type: "GD_GET_COURSE_META" });
    if (meta && meta.ok && meta.meta && meta.meta.name && !/^(course image|course|unknown|untitled|ivy stem international schools)$/i.test(String(meta.meta.name).trim())) {
      record.name = String(meta.meta.name).trim().slice(0, 120);
      record.courseNameSource = meta.meta.source || "course-page";
    }
    await prog("Finding GradeBook");
    const f = await sendToTab(tabId, { type: "GD_FIND_GRADEBOOK" });
    if (f && f.ok && f.href) {
      record.gradebookUrl = f.href;
      if (!f.clicked) await navigate(tabId, f.href);
    } else {
      record.warnings.push("GradeBook link not found on the course page - used the direct GradeBook URL");
      record.strategy = "direct GradeBook URL";
      await navigate(tabId, gbUrl);
    }
    let ping = await sendToTab(tabId, { type: "GD_PING" });
    if (!ping || !GB_RE.test(ping.path)) {
      record.warnings.push("Landed on " + (ping ? ping.path : "an unresponsive page") + " - retried the direct GradeBook URL");
      await navigate(tabId, gbUrl);
      ping = await sendToTab(tabId, { type: "GD_PING" });
    }
    record.timing.navMs = Date.now() - t0;
    if (!ping || !GB_RE.test(ping.path)) {
      return finish("FAILED_NAVIGATION", "Could not open the GradeBook (ended on " + (ping ? ping.path : "no response") + "). Check that you are still logged in.");
    }

    await prog("Reading GradeBook");
    const r = await sendToTab(tabId, { type: "GD_PARSE_GRADEBOOK" });
    if (!r) return finish("FAILED_NAVIGATION", "No response from the GradeBook page");
    if (r.trace) { record.parserId = r.trace.invoked || r.trace.selected; record.parserTrace = r.traceText; }
    record.timing.renderMs = r.renderMs;
    if (!r.ok) return finish(r.navigation ? "FAILED_NAVIGATION" : "FAILED_PARSING", r.error || "GradeBook parsing failed");

    record.diagnostics = r.diagnostics;
    // GradeBook pages expose the authoritative visible course title. Prefer it
    // over discovery-card placeholders such as "course image".
    if (r.courseName && !/^(course image|course|unknown|untitled|ivy stem international schools)$/i.test(String(r.courseName).trim())) {
      record.name = String(r.courseName).trim().slice(0, 120);
      record.courseNameSource = "gradebook-page";
    }
    record.items = normalizeTicketItems(r.items || []);
    record.courseLevel = r.courseLevel || [];
    filterRecordToQuarter(record, activeQuarter);
    record.ticketAnalysis = analyzeTickets(record.items);
    (r.diagnostics.warnings || []).forEach(w => record.warnings.push(w));
    if (record.parserId !== "ivy-gradebook") return finish("FAILED_PARSING", "Expected parser ivy-gradebook but " + record.parserId + " ran");
    if (record.items.length || record.courseLevel.length) return finish("SUCCESS");
    if (r.renderTimeout) return finish("FAILED_OTHER", "GradeBook did not finish rendering in time");
    if (r.empty) return finish("SUCCESS_EMPTY", "No graded items currently available.");
    return finish("FAILED_PARSING", "Ivy parser found the GradeBook but extracted 0 records");
  } catch (e) {
    return finish("FAILED_OTHER", String((e && e.message) || e));
  }
}


async function runDiscoveryOnly() {
  const settings = await getSettings();
  const startUrl = settings.startUrl || (LMS + "/courses");
  await setProgress({ phase: "discovering", discovered: 0, scanned: 0, succeeded: 0, failed: 0, current: "", step: "Finding all courses" });
  let tab;
  try { tab = await getTab(startUrl); } catch (e) {
    const err = "Could not open an LMS tab: " + String((e && e.message) || e);
    await setProgress({ phase: "error", error: err }); return { ok:false, error:err };
  }
  const disc = await discoverCourses(tab.id, startUrl);
  if (!disc.ok) { await setProgress({ phase:"error", error:disc.error }); return disc; }
  const now = Date.now();
  const catalog = disc.discovered.map(c => Object.assign({}, c, { status:"discovered", state:"DISCOVERED", items:[], courseLevel:[] }));
  const scan = { timestamp:now, pagesVisited:disc.pagesVisited, totalPages:disc.totalPages, discovered:catalog.length, duplicatesRemoved:disc.duplicatesRemoved, scanned:0, succeeded:0, failed:0, empty:0, discoveryOnly:true, courses:catalog };
  await chrome.storage.local.set({ gdCourseCatalog:catalog, gdDiscoveryComplete:true, gdAllGradesScanned:false, gdLastScan:scan, gdProgress:{ phase:"done", discovered:catalog.length, scanned:0, succeeded:0, failed:0, empty:0, pagesVisited:disc.pagesVisited.length, totalPages:disc.totalPages, finishedAt:now } });
  return {ok:true, discovered:catalog.length, discoveryOnly:true};
}

async function runGpaScan(filterIds) {
  const settings = await getSettings();
  const activeQuarter = Number(settings.activeQuarter || 1);
  const st = await chrome.storage.local.get(["gdCourseCatalog","gdLastScan","gdAllGradesScanned","gdQuarterScans"]);
  const currentQuarterScan = (st.gdQuarterScans && st.gdQuarterScans[String(activeQuarter)]) || null;
  if (filterIds && !currentQuarterScan) return {ok:false,error:"Scan All Grades must be completed for the selected quarter before scanning GPA subjects."};
  const catalog = st.gdCourseCatalog || ((st.gdLastScan||{}).courses || []).filter(c => c.url);
  if (!catalog.length) return {ok:false,error:"Run the first course discovery scan first."};
  const target = filterIds ? catalog.filter(c => filterIds.indexOf(c.id)!==-1) : catalog.slice();
  if (!target.length) return {ok:false,error:"No GPA subjects selected. Select at least one subject first."};
  let tab;
  try { tab = await getTab(settings.startUrl || (LMS + "/courses")); } catch(e) { return {ok:false,error:String((e&&e.message)||e)}; }
  const prev = (st.gdQuarterScans && st.gdQuarterScans[String(activeQuarter)]) || {};
  const prevById = new Map((prev.courses||[]).map(c=>[c.id,c]));
  let scanned=0,succeeded=0,failed=0,emptyCount=0;
  const results=new Map();
  await setProgress({phase:"scanning",discovered:catalog.length,total:target.length,scanned:0,succeeded:0,failed:0,empty:0,step:"Starting GPA scan"});
  for (const c of target) {
    if (cancelRequested) break;
    const prog=step=>setProgress({phase:"scanning",discovered:catalog.length,total:target.length,scanned,succeeded,failed,empty:emptyCount,current:c.name,step});
    const rec=await scanCourse(tab.id,c,prog,activeQuarter); results.set(c.id,rec); scanned++;
    if(rec.state==="SUCCESS"||rec.state==="SUCCESS_EMPTY") succeeded++; else failed++;
    if(rec.state==="SUCCESS_EMPTY") emptyCount++;
    await setProgress({phase:"scanning",discovered:catalog.length,total:target.length,scanned,succeeded,failed,empty:emptyCount,current:c.name,step:"Done"});
  }
  const courses=catalog.map(c=>results.has(c.id)?results.get(c.id):(prevById.get(c.id)||Object.assign({},c,{state:"SKIPPED",status:"skipped",items:[],courseLevel:[]})));
  const totals={succeeded:0,failed:0,empty:0}; courses.forEach(c=>{if(c.status==="ok"||c.status==="empty")totals.succeeded++; else if(c.status==="failed")totals.failed++; if(c.status==="empty")totals.empty++;});
  const now=Date.now(), scan={timestamp:now,pagesVisited:prev.pagesVisited||[],totalPages:prev.totalPages||0,discovered:catalog.length,duplicatesRemoved:prev.duplicatesRemoved||0,scanned,succeeded:totals.succeeded,failed:totals.failed,empty:totals.empty,retry:false,discoveryOnly:false,courses};
  let gpaNow=null; try{const g=GDG.computeGpa(courses,settings); if(g)gpaNow=Math.round(g.weighted*100)/100;}catch(e){}
  const hs=await chrome.storage.local.get("gdScanHistory"); const history=hs.gdScanHistory||[]; history.push({timestamp:now,gpa:gpaNow,discovered:catalog.length,succeeded:totals.succeeded,failed:totals.failed,empty:totals.empty,courses:courses.map(c=>({id:c.id,name:c.name,pct:GDG.coursePct(c)}))});
  const qs=await chrome.storage.local.get("gdQuarterScans"); const quarterScans=Object.assign({},qs.gdQuarterScans||{}); quarterScans[String(activeQuarter)]=scan;
  const saveState = {gdLastScan:scan,gdQuarterScans:quarterScans,gdScanHistory:history.slice(-50),gdCourseCatalog:catalog,gdDiscoveryComplete:true,gdProgress:{phase:"done",discovered:catalog.length,total:target.length,scanned,succeeded,failed,empty:emptyCount,pagesVisited:(prev.pagesVisited||[]).length,totalPages:prev.totalPages||0,finishedAt:now}};
  if (!filterIds) saveState.gdAllGradesScanned = true;
  await chrome.storage.local.set(saveState);
  return {ok:true,discovered:catalog.length,scanned,succeeded,failed};
}

async function runScanInner(filterIds) {
  const settings = await getSettings();
  const activeQuarter = Number(settings.activeQuarter || 1);
  const startUrl = settings.startUrl || (LMS + "/courses");
  await setProgress({ phase: "starting", discovered: 0, scanned: 0, succeeded: 0, failed: 0, current: "", step: "Opening the LMS" });

  let tab;
  try { tab = await getTab(startUrl); }
  catch (e) {
    await setProgress({ phase: "error", error: "Could not open an LMS tab: " + String((e && e.message) || e) });
    return { ok: false, error: "Could not open an LMS tab" };
  }
  const tabId = tab.id;

  const disc = await discoverCourses(tabId, startUrl);
  if (!disc.ok) { await setProgress({ phase: "error", error: disc.error }); return { ok: false, error: disc.error }; }
  const discovered = disc.discovered;
  const target = filterIds ? discovered.filter(c => filterIds.indexOf(c.id) !== -1) : discovered;

  const store0 = await chrome.storage.local.get(["gdLastScan","gdQuarterScans"]);
  const prevQuarterScan = (store0.gdQuarterScans && store0.gdQuarterScans[String(activeQuarter)]) || {};
  const prevById = new Map(((prevQuarterScan.courses || [])).map(c => [c.id, c]));

  const results = new Map();
  let scanned = 0, succeeded = 0, failed = 0, emptyCount = 0;
  const base = () => ({ phase: "scanning", discovered: discovered.length, total: target.length, scanned, succeeded, failed, empty: emptyCount, totalPages: disc.totalPages, pagesVisited: disc.pagesVisited.length });

  for (const c of target) {
    if (cancelRequested) break;
    const prog = step => setProgress(Object.assign(base(), { current: c.name, step: step, coursePage: c.page }));
    const rec = await scanCourse(tabId, c, prog, activeQuarter);
    results.set(c.id, rec);
    scanned++;
    if (rec.state === "SUCCESS" || rec.state === "SUCCESS_EMPTY") succeeded++; else failed++;
    if (rec.state === "SUCCESS_EMPTY") emptyCount++;
    await setProgress(Object.assign(base(), { current: c.name, step: "Done", coursePage: c.page }));
  }

  const courses = discovered.map(c => {
    if (results.has(c.id)) return results.get(c.id);
    if (filterIds && prevById.get(c.id)) return prevById.get(c.id);
    return Object.assign({}, c, { state: "SKIPPED", status: "skipped", note: "Scan cancelled", items: [], courseLevel: [] });
  });
  // Retry runs report totals for the whole course list, not just the retried subset.
  const totals = { succeeded: 0, failed: 0, empty: 0 };
  courses.forEach(c => {
    if (c.status === "ok" || c.status === "empty") totals.succeeded++;
    else if (c.status === "failed") totals.failed++;
    if (c.status === "empty") totals.empty++;
  });

  const now = Date.now();
  const scan = {
    timestamp: now, pagesVisited: disc.pagesVisited, totalPages: disc.totalPages,
    discovered: discovered.length, duplicatesRemoved: disc.duplicatesRemoved,
    scanned: courses.filter(c => c.status !== "skipped").length,
    succeeded: totals.succeeded, failed: totals.failed, empty: totals.empty,
    retry: !!filterIds, courses: courses
  };
  // Keep a compact, inspectable summary of the data that reaches GPA calculation.
  scan.gpaDiagnostics = {
    courseLevelFound: courses.filter(c => Array.isArray(c.courseLevel) && c.courseLevel.length).length,
    overallFound: courses.filter(c => GDG.coursePct(c) != null).length,
    gpaRelevant: courses.filter(c => GDG.courseClass(c, settings) === "main").length,
    included: (GDG.computeGpa(courses, settings) || { included: 0 }).included
  };

  let gpaNow = null;
  try { const g = GDG.computeGpa(courses, settings); if (g) gpaNow = Math.round(g.weighted * 100) / 100; } catch (e) { gpaNow = null; }
  const histStore = await chrome.storage.local.get("gdScanHistory");
  const history = histStore.gdScanHistory || [];
  history.push({ timestamp: now, gpa: gpaNow, discovered: discovered.length, succeeded: totals.succeeded, failed: totals.failed, empty: totals.empty, retry: !!filterIds,
    courses: courses.map(c => ({ id: c.id, name: c.name, pct: GDG.coursePct(c) })) });

  const qStore = await chrome.storage.local.get("gdQuarterScans");
  const quarterScans = Object.assign({}, qStore.gdQuarterScans || {});
  quarterScans[String(activeQuarter)] = scan;
  const save = { gdLastScan: scan, gdQuarterScans: quarterScans, gdScanHistory: history.slice(-50) };
  if (!filterIds) save.gdPrevScan = prevQuarterScan || null;
  save.gdProgress = { phase: "done", discovered: discovered.length, total: target.length, scanned, succeeded, failed, empty: emptyCount, pagesVisited: disc.pagesVisited.length, totalPages: disc.totalPages, finishedAt: now };
  await chrome.storage.local.set(save);
  return { ok: true, discovered: discovered.length, scanned, succeeded, failed };
}

async function runScan(filterIds) {
  if (running) return { ok: false, error: "A scan is already running" };
  running = true;
  cancelRequested = false;
  try { return await runScanInner(filterIds); }
  finally { running = false; cancelRequested = false; }
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg.type === "GD_START_SCAN") {
    chrome.storage.local.get("gdDiscoveryComplete").then(st => {
      if (st.gdDiscoveryComplete) return sendResponse({ok:false,error:"Course discovery is already complete. Use Scan All Grades."});
      return runDiscoveryOnly().then(r => sendResponse(r));
    }).catch(e => sendResponse({ ok:false, error:String((e&&e.message)||e) }));
    return true;
  }
  if (msg.type === "GD_SCAN_GPA_SUBJECTS") {
    runGpaScan(msg.ids || []).then(r=>sendResponse(r)).catch(e=>sendResponse({ok:false,error:String((e&&e.message)||e)}));
    return true;
  }
  if (msg.type === "GD_SCAN_ALL_GRADES") {
    runGpaScan(null).then(r=>sendResponse(r)).catch(e=>sendResponse({ok:false,error:String((e&&e.message)||e)}));
    return true;
  }
  if (msg.type === "GD_RETRY_FAILED") {
    getSettings().then(settings => {
      const q = String(Number(settings.activeQuarter || 1));
      return chrome.storage.local.get("gdQuarterScans").then(st => {
        const current = (st.gdQuarterScans && st.gdQuarterScans[q]) || null;
        const failedIds = ((current && current.courses) || []).filter(c => c.status === "failed").map(c => c.id);
        if (!failedIds.length) return sendResponse({ ok: false, error: "No failed courses to retry for the selected quarter" });
        return runScan(failedIds).then(r => sendResponse(r));
      });
    }).catch(e => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true;
  }
  if (msg.type === "GD_CANCEL") { cancelRequested = true; sendResponse({ ok: true }); return; }
  if (msg.type === "GD_SCAN_STATE") { sendResponse({ running: running }); return; }
});

