(function (root) {
"use strict";

var DEFAULT_LETTER_MAP = { "A+": 4, "A": 4, "A-": 3.7, "B+": 3.3, "B": 3, "B-": 2.7, "C+": 2.3, "C": 2, "C-": 1.7, "D+": 1.3, "D": 1, "D-": 0.7, "F": 0 };

var DEFAULT_SETTINGS = {
  startUrl: "https://lms.ivyis.org/courses",
  targetGpa: 3.5,
  minPercent: 93,
  dropThreshold: 5,
  healthyMin: 3.5,
  watchMin: 3.0,
  equalWeights: true,
  scaleMax: 4,
  alertLow: true,
  alertDrop: true,
  alertUngraded: true,
  ungradedAlertMin: 3,
  letterMap: DEFAULT_LETTER_MAP,
  percentBands: [["A+",97],["A",93],["A-",90],["B+",87],["B",83],["B-",80],["C+",77],["C",73],["C-",70],["D+",67],["D",63],["D-",60],["F",0]],
  weights: {},
  excluded: {},
  classOverride: {},
  gpaKeywords: ["math","algebra","geometry","calculus","language arts","english","ela","arabic","science","biology","chemistry","physics","social studies"],
  coreKeywords: [],
  activeQuarter: 1,
  selectedGpaSubjects: {},
  lockedQuarters: []
};

function mergeSettings(saved) {
  saved = saved || {};
  var s = {};
  var k;
  for (k in DEFAULT_SETTINGS) s[k] = DEFAULT_SETTINGS[k];
  for (k in saved) s[k] = saved[k];
  s.letterMap = Object.assign({}, DEFAULT_LETTER_MAP, saved.letterMap || {});
  s.weights = Object.assign({}, saved.weights || {});
  s.excluded = Object.assign({}, saved.excluded || {});
  s.classOverride = Object.assign({}, saved.classOverride || {});
  s.percentBands = (saved.percentBands && saved.percentBands.length) ? saved.percentBands.slice() : DEFAULT_SETTINGS.percentBands.slice();
  s.gpaKeywords = (saved.coreKeywords && saved.coreKeywords.length)
    ? saved.coreKeywords.slice()
    : DEFAULT_SETTINGS.coreKeywords.slice();
  s.coreKeywords = Array.isArray(saved.coreKeywords) ? saved.coreKeywords.slice() : [];
  s.activeQuarter = Math.min(4, Math.max(1, Number(saved.activeQuarter || 1)));
  s.selectedGpaSubjects = Object.assign({}, saved.selectedGpaSubjects || {});
  s.lockedQuarters = Array.isArray(saved.lockedQuarters) ? saved.lockedQuarters.slice() : [];
  return s;
}

function percentToLetter(p, bands) {
  p = Number(p);
  if (!isFinite(p)) return null;
  for (var i = 0; i < bands.length; i++) { if (p >= bands[i][1]) return bands[i][0]; }
  return "F";
}
function letterToPoints(letter, map) {
  if (!letter) return null;
  var l = String(letter).trim().toUpperCase();
  if (map && map[l] != null) return map[l];
  if (DEFAULT_LETTER_MAP[l] != null) return DEFAULT_LETTER_MAP[l];
  return null;
}

function courseClass(course, settings) {
  var q = String(settings.activeQuarter || 1);
  var selected = settings.selectedGpaSubjects && settings.selectedGpaSubjects[q];
  if (Array.isArray(selected)) return selected.indexOf(String(course.id)) !== -1 ? "main" : "other";
  if (settings.classOverride && settings.classOverride[course.id]) return settings.classOverride[course.id];
  return "other";
}

function courseWeight(course, settings) {
  if (!settings.equalWeights && settings.weights && Number(settings.weights[course.id]) > 0) {
    return { w: Number(settings.weights[course.id]), kind: "custom" };
  }
  return { w: 1, kind: "equal" };
}

function courseLevelRows(c) { return Array.isArray(c && c.courseLevel) ? c.courseLevel : []; }
function findOverall(c) {
  var cl = courseLevelRows(c), i, t, label;
  for (i = 0; i < cl.length; i++) {
    t = cl[i] || {}; label = String(t.label || t.name || "").trim().toLowerCase();
    if (label === "overall" || label === "course grade" || label === "final grade" || label === "total") return t;
  }
  return null;
}
function quarterRows(c, settings) {
  var q = Number(settings && settings.activeQuarter || c && c.quarter || 0);
  if (!q) return [];
  var rows = Array.isArray(c && c.items) ? c.items : [];
  var marker = new RegExp('^\\s*(?:quarter\\s*|q)'+q+'\\s*$', 'i');
  return rows.filter(function (t) { return marker.test(String(t && (t.name || t.label) || '').trim()); });
}
function gradeValue(row) {
  if (!row) return null;
  if (row.percentage != null) return Number(row.percentage);
  if (row.score != null && Number(row.max)) return Math.round(Number(row.score) / Number(row.max) * 1000) / 10;
  return null;
}
function coursePct(c, settings) {
  var qr = quarterRows(c, settings), i, t, cl, overall;
  // A quarter row is the quarter's own grade and must take precedence over
  // any quarter-neutral Overall/Final row. This prevents Q1 grades from
  // becoming the Q2 GPA when Q2 has not started yet.
  for (i = 0; i < qr.length; i++) {
    t = qr[i];
    var qp = gradeValue(t);
    if (qp != null) return qp;
  }
  cl = courseLevelRows(c);
  overall = findOverall(c);
  if (overall) {
    var op = gradeValue(overall);
    if (op != null) return op;
  }
  for (i = 0; i < cl.length; i++) { t = cl[i]; if (t && t.percentage != null) return Number(t.percentage); }
  for (i = 0; i < cl.length; i++) { t = cl[i]; if (t && t.score != null && Number(t.max)) return Math.round(Number(t.score) / Number(t.max) * 1000) / 10; }
  return null;
}
function courseLetter(c, settings) {
  var qr = quarterRows(c, settings), i, t, overall = findOverall(c), cl = courseLevelRows(c);
  for (i = 0; i < qr.length; i++) { t = qr[i]; if (t && t.letter) return t.letter; }
  if (overall && overall.letter) return overall.letter;
  for (i = 0; i < cl.length; i++) { t = cl[i]; if (t && t.letter) return t.letter; }
  return null;
}

function coursePoints(c, settings) {
  var letter = courseLetter(c, settings);
  var points = letter ? letterToPoints(letter, settings.letterMap) : null;
  var source = letter ? "LMS-provided letter" : null;
  var pct = coursePct(c, settings);
  if (points == null && pct != null) {
    letter = percentToLetter(pct, settings.percentBands);
    points = letterToPoints(letter, settings.letterMap);
    source = "GradeDash estimate (percent to letter)";
  }
  return { points: points, letter: letter, source: source };
}

function computeGpa(courses, settings) {
  var rows = [], i, c;
  for (i = 0; i < courses.length; i++) {
    c = courses[i];
    if (courseClass(c, settings) !== "main") continue;
    if (settings.excluded && settings.excluded[c.id]) continue;
    var cp = coursePoints(c, settings);
    var letter = cp.letter, points = cp.points, source = cp.source;
    if (points == null) continue;
    var w = courseWeight(c, settings);
    rows.push({ course: c, points: points, letter: letter, weight: w.w, weightKind: w.kind, source: source });
  }
  if (!rows.length) return null;
  var tw = 0, pts = 0, custom = false, un = 0;
  rows.forEach(function (r) { tw += r.weight; pts += r.points * r.weight; if (r.weightKind === "custom") custom = true; un += r.points; });
  return {
    weighted: pts / tw,
    unweighted: un / rows.length,
    included: rows.length,
    totalWeight: tw,
    weighting: custom ? "Custom weighting" : "Equal weighting",
    rows: rows,
    label: "Calculated GPA - GradeDash estimate (not an official LMS value)"
  };
}

function healthStatus(gpa, settings) {
  if (gpa == null || !isFinite(gpa)) return { key: "none", label: "No GPA yet", emoji: "\u2013" };
  if (gpa >= settings.healthyMin) return { key: "healthy", label: "Healthy", emoji: "\uD83D\uDFE2" };
  if (gpa >= settings.watchMin) return { key: "watch", label: "Watch", emoji: "\uD83D\uDFE1" };
  return { key: "attention", label: "Needs Attention", emoji: "\uD83D\uDD34" };
}

function requiredAvg(currentPct, gradedCount, remainingCount, targetPct) {
  currentPct = Number(currentPct); targetPct = Number(targetPct);
  if (!isFinite(currentPct) || !isFinite(targetPct)) return null;
  if (!remainingCount || remainingCount < 1) return null;
  var total = gradedCount + remainingCount;
  if (total <= 0) return null;
  return (targetPct * total - currentPct * gradedCount) / remainingCount;
}

function targetGpaNeeded(courses, settings) {
  var n = 0, sum = 0, k = 0, remainingNames = [];
  courses.forEach(function (c) {
    if (courseClass(c, settings) !== "main") return;
    if (settings.excluded && settings.excluded[c.id]) return;
    var points = coursePoints(c, settings).points;
    var w = courseWeight(c, settings).w;
    if (points != null) { n += w; sum += points * w; }
    else { k += w; remainingNames.push(c.name); }
  });
  if (!k || !n) return { needed: null, remainingCount: k, currentCount: n, remainingNames: remainingNames };
  return { needed: (settings.targetGpa * (n + k) - sum) / k, remainingCount: k, currentCount: n, remainingNames: remainingNames };
}

root.GD = {
  DEFAULT_SETTINGS: DEFAULT_SETTINGS,
  DEFAULT_LETTER_MAP: DEFAULT_LETTER_MAP,
  mergeSettings: mergeSettings,
  percentToLetter: percentToLetter,
  letterToPoints: letterToPoints,
  courseClass: courseClass,
  courseWeight: courseWeight,
  coursePct: coursePct,
  courseLetter: courseLetter,
  coursePoints: coursePoints,
  computeGpa: computeGpa,
  healthStatus: healthStatus,
  requiredAvg: requiredAvg,
  targetGpaNeeded: targetGpaNeeded
};
})(typeof window !== "undefined" ? window : globalThis);
