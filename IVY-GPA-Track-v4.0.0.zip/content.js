(function () {
"use strict";

var LMS_ORIGIN = location.origin;
var COURSE_HREF = /\/courses\/([A-Za-z0-9_-]+)\/?$/;
var GRADEBOOK_RE = /\/courses\/[^/]+\/gradingitemslist/;
var EMPTY_TEXT = /no (grading |graded )?(items|records|data|grades)( found| available| yet)?|nothing to (show|display)/i;
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

function textOf(el) { return (el.textContent || "").replace(/\s+/g, " ").trim(); }
function cleanText(el) { return window.IvyParser ? window.IvyParser.cellText(el) : textOf(el); }
function bodyText() { return document.body ? textOf(document.body) : ""; }
function isVisible(el) {
  if (!el) return false;
  if (el.closest('[aria-hidden="true"]')) return false;
  var st = getComputedStyle(el);
  if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) === 0) return false;
  var r = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
  return !!el.offsetParent || !!(r && (r.width > 0 || r.height > 0)) || el === document.body || el === document.documentElement;
}

function courseLinks() {
  var out = new Map();
  Array.prototype.slice.call(document.querySelectorAll("a[href]")).forEach(function (a) {
    var href = a.getAttribute("href") || "";
    var m = href.match(COURSE_HREF);
    if (!m || !isVisible(a)) return;
    var id = m[1];
    if (out.has(id)) return;
    var name = cleanText(a) || a.getAttribute("aria-label") || "";
    if (!name) { var img = a.querySelector("img"); name = img ? (img.getAttribute("alt") || "") : ""; }
    if (!name) return;
    out.set(id, { id: id, name: name.slice(0, 120), url: new URL(href, LMS_ORIGIN).href });
  });
  return Array.from(out.values());
}

function findNextControl() {
  var cands = Array.prototype.slice.call(document.querySelectorAll("button, a, li, [role='button']")).filter(isVisible);
  for (var i = 0; i < cands.length; i++) {
    var c = cands[i];
    if (c.tagName === "LI" && c.querySelector("button, a")) continue;
    var label = ((c.getAttribute("aria-label") || "") + " " + textOf(c)).trim();
    if (/\bnext\b|next page/i.test(label)) return c;
    if (/[\u203A\u00BB>]/.test(label) && label.length <= 3) return c;
  }
  return null;
}

function pageNumbers() {
  var nums = [];
  Array.prototype.slice.call(document.querySelectorAll(".MuiPaginationItem-root, .MuiPaginationItem-page, [aria-label^='page'], [aria-label^='Go to page']")).forEach(function (el) {
    if (!isVisible(el)) return;
    var t = textOf(el);
    var n = parseInt(t, 10);
    if (n > 0 && String(n) === t) nums.push(n);
  });
  return nums;
}

function paginationState() {
  var current = null;
  var cur = document.querySelector('.MuiPaginationItem-root[aria-current="true"], .MuiPaginationItem-root[aria-current="page"], [aria-current="page"], .Mui-selected');
  if (cur) current = parseInt(textOf(cur), 10) || null;
  var nums = pageNumbers();
  var total = nums.length ? Math.max.apply(null, nums) : null;
  var nextBtn = findNextControl();
  var hasNext = false;
  if (nextBtn) {
    hasNext = !(nextBtn.disabled === true || nextBtn.getAttribute("disabled") != null ||
      nextBtn.getAttribute("aria-disabled") === "true" || (nextBtn.getAttribute("class") || "").indexOf("Mui-disabled") !== -1);
  }
  return { current: current, total: total, hasNext: hasNext };
}

async function waitCoursesReady() {
  var deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    if (courseLinks().length) return { type: "courses" };
    await sleep(300);
  }
  return { type: "courses-timeout" };
}


function hasIvyGradeCards() {
  var els = Array.prototype.slice.call(document.querySelectorAll("div, section, article, li, span"));
  return els.some(function (el) {
    if (!isVisible(el)) return false;
    var t = textOf(el);
    if (!t || t.length > 350) return false;
    return /(?:^|\s)Name\s*:\s*.+?\s*(?=(?:Max|Maximum|Out of)\s*:)(?:Max|Maximum|Out of)\s*:\s*\d+(?:\.\d+)?\s*(?=(?:Score|Mark|Grade)\s*:)(?:Score|Mark|Grade)\s*:\s*(?:\d+(?:\.\d+)?|[A-F][+-]?)/i.test(t);
  });
}

// Ready when the table/card row count is stable across polls and no loader is visible,
// or when the page shows an explicit empty-state message.
function hasExplicitEmptyState() {
  var els = Array.prototype.slice.call(document.querySelectorAll("[role='status'], [role='alert'], .MuiAlert-root, .MuiTypography-root, p, div"));
  return els.some(function (el) {
    if (!isVisible(el)) return false;
    var t = textOf(el);
    if (!t || t.length > 220) return false;
    return EMPTY_TEXT.test(t);
  });
}

// React can briefly render an empty-state shell before the GradeBook data arrives.
// Do not treat that transient state as a real empty GradeBook. Require either
// actual grade content or a stable explicit empty-state after a grace period.
async function waitGradebookReady() {
  var t0 = Date.now(), deadline = t0 + 20000, lastRows = -1, stableRows = 0;
  var emptySince = null;
  var MIN_EMPTY_WAIT = 1800;
  while (Date.now() < deadline) {
    var busy = Array.prototype.slice.call(document.querySelectorAll(".MuiCircularProgress-root, .MuiSkeleton-root, .MuiLinearProgress-root, [role='progressbar']")).some(isVisible);
    var hasTable = !!document.querySelector("table, .MuiTable-root, [role='table'], [role='grid']");
    var rows = document.querySelectorAll("tr, [role='row']").length;
    var hasCards = hasIvyGradeCards();

    if (!busy && ((hasTable && rows > 0) || hasCards)) {
      if (hasCards || rows === lastRows) stableRows++; else stableRows = 0;
      lastRows = rows;
      if (stableRows >= 2) return { type: "gradebook", ms: Date.now() - t0 };
      emptySince = null;
    } else if (!busy && hasExplicitEmptyState() && Date.now() - t0 >= MIN_EMPTY_WAIT) {
      if (emptySince == null) emptySince = Date.now();
      if (Date.now() - emptySince >= 750) return { type: "gradebook-empty", ms: Date.now() - t0 };
    } else {
      emptySince = null;
    }
    await sleep(250);
  }
  return { type: "gradebook-timeout", ms: Date.now() - t0 };
}

async function goNextPage() {
  var pag = paginationState();
  if (!pag.hasNext) return { ok: false, error: "No next page" };
  var nextBtn = findNextControl();
  if (!nextBtn) return { ok: false, error: "Next control not found" };
  var beforeIds = new Set(courseLinks().map(function (x) { return x.id; }));
  var beforeCurrent = pag.current;
  nextBtn.click();
  var deadline = Date.now() + 10000;
  while (Date.now() < deadline) {
    var now = courseLinks();
    var nowPag = paginationState();
    var changed = now.some(function (x) { return !beforeIds.has(x.id); }) || (nowPag.current !== beforeCurrent && nowPag.current != null);
    if (changed) { await sleep(500); return { ok: true }; }
    await sleep(300);
  }
  return { ok: false, error: "Courses page did not change after clicking next" };
}

function courseMeta() {
  var bad = /^(courses?|gradebook|grades?|dashboard|home|overview|menu|course image)$/i;
  var candidates = [];
  // Ivy's course page can render the title only as a breadcrumb/heading after
  // React finishes mounting. Prefer a visible heading that is clearly a course
  // title, including the common "Subject : Section" format.
  function addCourseTitleText(t, source) {
    t = String(t || "").replace(/\s+/g, " ").trim();
    if (!t || t.length < 3 || t.length > 140) return;
    t = t.replace(/^#\s*/, "").trim();
    if (bad.test(t) || /^(grade\s*book|grades?|grading)$/i.test(t)) return;
    if (/^courses?\s*[>/]/i.test(t)) t = t.split(/[>\/]/).pop().trim();
    if (!t || bad.test(t)) return;
    candidates.push({ text: t, source: source });
  }
  function add(el, source) {
    if (!el || !isVisible(el)) return;
    var t = cleanText(el) || textOf(el);
    if (!t) return;
    t = t.replace(/\s+/g, " ").trim();
    if (!t || t.length < 3 || t.length > 140 || bad.test(t)) return;
    if (/^(courses?)\s*[>/]/i.test(t)) t = t.split(/[>\\/]/).pop().trim();
    if (!t || bad.test(t)) return;
    candidates.push({ text: t, source: source });
  }
  Array.prototype.slice.call(document.querySelectorAll("h1, h2, h3")).forEach(function (el) { add(el, "heading"); });
  Array.prototype.slice.call(document.querySelectorAll("[aria-current='page'], .MuiBreadcrumbs-li, nav a, nav li")).forEach(function (el) { add(el, "breadcrumb"); });
  var title = document.title || "";
  if (title) add({ textContent: title }, "document-title");

  // Also inspect visible text blocks for Ivy's distinctive "# Course : Section"
  // heading when the semantic heading/breadcrumb nodes are not exposed cleanly.
  Array.prototype.slice.call(document.querySelectorAll("h1, h2, h3, h4, h5, h6, [role='heading'], p, span, div, li"))
    .filter(isVisible)
    .forEach(function (el) {
      if (el.children.length > 4) return;
      var t = textOf(el);
      if (/^#?\s*[^:]{2,100}\s*:\s*[^:]{1,80}$/.test(t) && !/gradebook|grades?|grading/i.test(t)) addCourseTitleText(t, "ivy-title-text");
    });

  var preferred = candidates.find(function (x) {
    return x.source === "ivy-title-text" && /:\s*[^:]+$/.test(x.text) &&
      !/ivy\\s+stem\\s+international\\s+schools/i.test(x.text);
  });
  if (!preferred) preferred = candidates.find(function (x) { return x.source === "heading" && !/^(course|grade|grades|grading)/i.test(x.text); });
  if (!preferred) preferred = candidates.find(function (x) { return x.source === "breadcrumb" && !/^(course|grade|grades|grading)/i.test(x.text); });
  if (!preferred) preferred = candidates.find(function (x) { return x.source === "document-title" && !/ivy\s+international|grade\s*dash/i.test(x.text); });
  return preferred ? { name: preferred.text.slice(0, 120), source: preferred.source } : null;
}

async function findGradebook() {
  var deadline = Date.now() + 12000;
  while (Date.now() < deadline) {
    var a = document.querySelector("a[href*='gradingitemslist']");
    if (a) return { ok: true, href: new URL(a.getAttribute("href"), LMS_ORIGIN).href, via: "link-href" };
    var cands = Array.prototype.slice.call(document.querySelectorAll("a, button, [role='button'], [role='tab'], li")).filter(isVisible);
    for (var i = 0; i < cands.length; i++) {
      var c = cands[i];
      if (!/^(grade\s?book|grades)$/i.test(cleanText(c))) continue;
      var href = c.getAttribute("href");
      if (href) return { ok: true, href: new URL(href, LMS_ORIGIN).href, via: "link-text" };
      c.click();
      var d2 = Date.now() + 8000;
      while (Date.now() < d2) {
        if (GRADEBOOK_RE.test(location.pathname)) return { ok: true, clicked: true, href: location.href, via: "click" };
        await sleep(250);
      }
    }
    await sleep(300);
  }
  return { ok: false, error: "GradeBook link not found on course page" };
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  (async function () {
    try {
      if (msg.type === "GD_PING") return sendResponse({ ok: true, path: location.pathname, href: location.href, hasIvy: !!window.IvyParser });

      if (msg.type === "GD_PARSE_COURSES") {
        var ready = await waitCoursesReady();
        var courses = courseLinks();
        if (!courses.length) return sendResponse({ ok: false, error: "No course links found on " + location.pathname + (ready.type === "courses-timeout" ? " (render timeout)" : "") });
        return sendResponse({ ok: true, courses: courses, pagination: paginationState(), pageUrl: location.href, ready: ready.type });
      }

      if (msg.type === "GD_NEXT_PAGE") return sendResponse(await goNextPage());
      if (msg.type === "GD_FIND_GRADEBOOK") return sendResponse(await findGradebook());
      if (msg.type === "GD_GET_COURSE_META") return sendResponse({ ok: true, meta: courseMeta(), path: location.pathname });

      if (msg.type === "GD_PARSE_GRADEBOOK") {
        if (!GRADEBOOK_RE.test(location.pathname)) return sendResponse({ ok: false, navigation: true, error: "Not on a GradeBook page: " + location.pathname });
        var ready2 = await waitGradebookReady();
        var run = window.GDParsers.run();
        var tt = window.GDParsers.traceText(run.trace);
        if (!run.ok) return sendResponse({ ok: false, error: run.error, trace: run.trace, traceText: tt, renderMs: ready2.ms });
        var res = run.result;
        var noData = res.items.length === 0 && res.courseLevel.length === 0;
        return sendResponse({
          ok: true,
          items: res.items,
          courseLevel: res.courseLevel,
          courseName: res.courseName || null,
          diagnostics: res.diagnostics,
          trace: run.trace,
          traceText: tt,
          renderMs: ready2.ms,
          ready: ready2.type,
          empty: !!(noData && ready2.type !== "gradebook-timeout" && (res.diagnostics.candidateRows === 0 || ready2.type === "gradebook-empty")),
          renderTimeout: ready2.type === "gradebook-timeout"
        });
      }

      return sendResponse({ ok: false, error: "Unknown message type: " + msg.type });
    } catch (e) {
      return sendResponse({ ok: false, error: String((e && e.message) || e) });
    }
  })();
  return true;
});
})();
