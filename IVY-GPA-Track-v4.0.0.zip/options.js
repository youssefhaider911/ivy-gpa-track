(function () {
"use strict";
const store = chrome.storage.local;
const $ = id => document.getElementById(id);

function parseMap(text) {
  const out = {};
  text.split("\n").forEach(line => {
    const m = line.split("=");
    if (m.length < 2) return;
    const k = m[0].trim().toUpperCase();
    const v = parseFloat(m.slice(1).join("="));
    if (k && isFinite(v)) out[k] = v;
  });
  return out;
}
function mapToText(map) {
  return Object.keys(map).sort().map(k => k + " = " + map[k]).join("\n");
}
function parseBands(text) {
  const out = [];
  text.split("\n").forEach(line => {
    const m = line.split("=");
    if (m.length < 2) return;
    const k = m[0].trim().toUpperCase();
    const v = parseFloat(m[1]);
    if (k && isFinite(v)) out.push([k, v]);
  });
  return out.sort((a, b) => b[1] - a[1]);
}

async function load() {
  const st = await store.get("gdSettings");
  const s = GD.mergeSettings(st.gdSettings || {});
  $("targetGpa").value = s.targetGpa;
  $("minPercent").value = s.minPercent;
  $("dropThreshold").value = s.dropThreshold;
  $("healthyMin").value = s.healthyMin;
  $("watchMin").value = s.watchMin;
  $("equalWeights").checked = !!s.equalWeights;
  $("scaleMax").value = s.scaleMax;
  $("alertLow").checked = !!s.alertLow;
  $("alertDrop").checked = !!s.alertDrop;
  $("alertUngraded").checked = !!s.alertUngraded;
  $("ungradedAlertMin").value = s.ungradedAlertMin;
  $("letterMap").value = mapToText(s.letterMap);
  $("percentBands").value = s.percentBands.map(b => b[0] + " = " + b[1]).join("\n");
  $("coreKeywords").value = s.coreKeywords.join(", ");
  $("startUrl").value = s.startUrl;
}

$("save").addEventListener("click", async () => {
  const st = await store.get("gdSettings");
  const s = GD.mergeSettings(st.gdSettings || {});
  s.targetGpa = parseFloat($("targetGpa").value) || 3.5;
  s.minPercent = parseFloat($("minPercent").value) || 93;
  s.dropThreshold = parseFloat($("dropThreshold").value) || 5;
  s.healthyMin = parseFloat($("healthyMin").value) || 3.5;
  s.watchMin = parseFloat($("watchMin").value) || 3.0;
  s.equalWeights = $("equalWeights").checked;
  s.scaleMax = parseFloat($("scaleMax").value) || 4;
  s.alertLow = $("alertLow").checked;
  s.alertDrop = $("alertDrop").checked;
  s.alertUngraded = $("alertUngraded").checked;
  s.ungradedAlertMin = parseInt($("ungradedAlertMin").value, 10) || 3;
  const lm = parseMap($("letterMap").value);
  if (Object.keys(lm).length) s.letterMap = lm;
  const pb = parseBands($("percentBands").value);
  if (pb.length) s.percentBands = pb;
  s.coreKeywords = $("coreKeywords").value.split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
  s.gpaKeywords = s.coreKeywords.slice();
  s.startUrl = $("startUrl").value.trim() || "https://lms.ivyis.org/courses";
  await store.set({ gdSettings: s });
  const sv = $("saved");
  sv.style.display = "inline";
  setTimeout(() => { sv.style.display = "none"; }, 2000);
});

$("clear-history").addEventListener("click", async () => {
  if (!confirm("Delete local scan history (trends)? Settings and the latest scan are kept.")) return;
  await store.set({ gdScanHistory: [], gdPrevScan: null });
});

$("clear-all").addEventListener("click", async () => {
  if (!confirm("Delete all locally stored scans, history and settings?")) return;
  await store.remove(["gdLastScan", "gdPrevScan", "gdScanHistory", "gdProgress", "gdSettings"]);
  load();
});

load();
})();
