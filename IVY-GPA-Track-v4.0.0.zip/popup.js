(function () {
"use strict";
const store = chrome.storage.local;
const $ = id => document.getElementById(id);

async function refresh() {
  const st = await store.get(["gdLastScan", "gdProgress", "gdSettings", "gdDiscoveryComplete", "gdAllGradesScanned", "gdQuarterScans"]);
  const settings = GD.mergeSettings(st.gdSettings || {});
  const quarterView = String((st.gdSettings || {}).quarterView || settings.activeQuarter || 1);
  const last = quarterView === "all" ? st.gdLastScan : ((st.gdQuarterScans || {})[String(settings.activeQuarter)] || null);
  const quarterScanned = quarterView === "all" ? !!st.gdAllGradesScanned : !!((st.gdQuarterScans || {})[String(settings.activeQuarter)]);
  const prog = st.gdProgress || {};
  const scanning = prog.phase === "scanning" || prog.phase === "starting" || prog.phase === "discovering";
  $("scan").disabled = scanning;
  $("scan").style.display = st.gdDiscoveryComplete ? "none" : "block";
  $("scan-gpa").style.display = (st.gdDiscoveryComplete && quarterScanned) ? "block" : "none";
  $("scan-all").style.display = st.gdDiscoveryComplete ? "block" : "none";
  $("scan-gpa").disabled = scanning; $("scan-all").disabled = scanning;
  $("cancel").style.display = scanning ? "block" : "none";

  if (last) {
    const g = quarterScanned ? GD.computeGpa(last.courses || [], settings) : null;
    const h = GD.healthStatus(g ? g.weighted : null, settings);
    $("gpa").innerHTML = g ? (g.weighted.toFixed(2) + " <small>/ " + Number(settings.scaleMax).toFixed(2) + " &middot; " + h.emoji + " " + h.label + "</small>") : (quarterScanned ? "GPA <small>no GPA grade available for this quarter yet</small>" : "GPA <small>scan this quarter first</small>");
    $("counts").innerHTML = "<span>Discovered <b>" + last.discovered + "</b></span><span>Scanned <b>" + (last.succeeded + last.failed) + "/" + last.discovered + "</b></span><span>Succeeded <b>" + last.succeeded + "</b></span><span>Failed <b>" + last.failed + "</b></span>";
    $("lastscan").textContent = "Last scan: " + new Date(last.timestamp).toLocaleString();
  } else {
    $("counts").innerHTML = "<span>Discovered <b>&mdash;</b></span><span>Scanned <b>&mdash;</b></span><span>Failed <b>&mdash;</b></span>";
    $("lastscan").textContent = "";
  }

  if (scanning) {
    let t = "Scanning all grades... ";
    if (prog.discovered) t += "Discovered: " + prog.discovered + " - Scanned: " + (prog.scanned || 0) + "/" + (prog.total || prog.discovered);
    if (prog.current) t += " - " + prog.current + " (" + (prog.step || "") + ")";
    $("progress").textContent = t;
  } else if (prog.error) {
    $("progress").textContent = "Error: " + prog.error;
  } else {
    $("progress").textContent = "";
  }
}

$("scan").addEventListener("click", () => chrome.runtime.sendMessage({ type: "GD_START_SCAN" }));
$("scan-gpa").addEventListener("click", () => chrome.tabs.create({url:"dashboard.html"}));
$("scan-all").addEventListener("click", () => chrome.runtime.sendMessage({ type: "GD_SCAN_ALL_GRADES" }));
$("cancel").addEventListener("click", () => chrome.runtime.sendMessage({ type: "GD_CANCEL" }));
$("open-dash").addEventListener("click", e => { e.preventDefault(); chrome.tabs.create({ url: "dashboard.html" }); window.close(); });
$("open-opts").addEventListener("click", e => { e.preventDefault(); chrome.tabs.create({ url: "options.html" }); window.close(); });

chrome.runtime.onMessage.addListener(msg => { if (msg.type === "GD_PROGRESS") refresh(); });
refresh();
const timer = setInterval(refresh, 1500);
window.addEventListener("unload", () => clearInterval(timer));
})();
