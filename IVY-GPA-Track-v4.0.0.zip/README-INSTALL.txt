GPA Track for Ivy LMS - v2.2.2 (Chrome Manifest V3)
===================================================

INSTALL
1. Unzip this file. You get a folder called "GPA Track".
2. Open chrome://extensions and turn on "Developer mode" (top right).
3. Click "Load unpacked" and select the "GPA Track" folder (the one containing manifest.json).
4. Open https://lms.ivyis.org/ and log in as usual (GPA Track never sees your password).
5. Click the GPA Track icon -> "Scan All Courses", or open the full dashboard.

HOW THE SCAN WORKS
Courses page -> every pagination page (follows "next" until it is disabled; no fixed course or page count)
-> de-duplicate by course ID -> for each course: open course page -> find GradeBook link
-> open /courses/{id}/gradingitemslist -> wait for the rendered GradeBook -> parse with ivy-gradebook (including the live Material UI card layout).

PARSER RULES
- On Ivy GradeBook pages the parser is always "ivy-gradebook". Each course records the trace:
  detected: ivy | matched: ivy | selected: ivy-gradebook | invoked: ivy-gradebook
- The generic parser is only allowed when no supported LMS is detected. It can never replace Ivy.
- It ignores badges, chips, counters, avatars, buttons, hidden and aria-hidden elements, and Weight columns.
- Ungraded items are kept with empty grades and are never counted as zero.
- Total / Overall / Final / Course Grade rows are stored separately as course-level grades.

SCAN STATES
SUCCESS, SUCCESS_EMPTY (no grading items), FAILED_NAVIGATION, FAILED_PARSING, FAILED_OTHER.
Use "Retry Failed" to re-scan only the failed courses.

GPA
All GPA values are GPA Track calculations, NOT official Ivy GPA. The letter -> points mapping, scale,
thresholds, course inclusion and credits can all be changed in Settings or the dashboard's GPA Calculator.

PRIVACY
All data stays in chrome.storage.local on this device. There is no backend, no telemetry, no uploads,
and no credentials are stored. Export to CSV/JSON or Print happens locally.

TESTS (optional, for developers)
node tests/integration.test.js
Runs the real extension files against a simulated multi-page Ivy LMS: pagination, every course,
ivy-gradebook selection/invocation, no generic fallback, extraction, GPA, alerts and dashboard rendering.


v2.2.2 parser fix: Ivy GradeBook pages that render grading entries as Material UI cards (for example 'Name: Overall Max: 100 Score:79.73') are now detected and parsed directly. The readiness check also recognizes these cards instead of waiting only for HTML tables.


v2.2.2 fixes a packaging syntax error in the Ivy card parser and verifies the live screenshot-style structure: Name/Max/Score rendered as separate Material UI card elements, e.g. "Name: Overall", "Max: 100", "Score:79.73". That value is parsed once as an Overall course-level grade (79.73/100).


GPA Track v2.3.5
What changed:
- Fixed course-name capture: GPA Track now reads the real course title from the course page before scanning the GradeBook, instead of keeping placeholders such as "course image".
- GPA classification now uses the real course title, with more academic subject keywords. PE/art/music/club/advisory-style courses remain excluded by default.
- Existing manual Main/Other overrides still win.
- No credentials, backend, telemetry, or external data storage were added.

Quick summary:
1) Reload the extension.
2) Open GPA Track Dashboard.
3) Scan All Courses.
4) You should now see real course names and GPA-relevant courses.
5) If one course is classified incorrectly, use its manual class override.


v2.3.5 fix:
- Captures the authoritative course title from the Ivy GradeBook page itself.
- Replaces discovery placeholders such as "course image" before GPA classification.
- Keeps subject keyword classification and manual overrides.
