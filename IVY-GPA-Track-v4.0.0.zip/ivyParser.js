(function () {
"use strict";
// ivy-gradebook: dedicated parser for Ivy LMS /courses/{id}/gradingitemslist (React + MUI tables).

var SCORE_MAX = /^\s*(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)\s*$/;
var PCT = /^\s*(\d+(?:\.\d+)?)\s*%\s*$/;
var LETTER = /^\s*([A-F][+-]?)\s*$/;
var BARE_NUM = /^\s*(\d+(?:\.\d+)?)\s*$/;
var COURSE_LEVEL = /^(total|overall|final grade|final|course grade|overall grade|total grade|current grade)\b/i;
var SUMMARY_RE = /^(total|overall|final|course|current)\s*(grade|score|average|mark)?\s*[:\-\u2013]?\s*(.+)$/i;
var CATEGORY_RE = /(quiz|homework|hw|test|exam|project|assignment|lab|classwork|participation|essay|worksheet|activity|assessment)/i;
var NON_NAME = /^(menu|actions?|details|view|edit|delete|open|more|status|score|grade|points|percent|letter|name|item|category|type|weight|due date|date|average|graded|ungraded|pending|late|missing|submitted|not submitted)$/i;
var HEADERISH = /^(item|name|assignment|grade item|category|type|score|max|max points|points|percent|percentage|letter|grade|status|due|due date|weight|actions?)$/i;
var WEIGHT_HEADER = /weight|worth|% of/i;
var SCORE_HEADER = /score|points|mark|grade|result/i;
var PCT_HEADER = /percent|%/i;
var MAX_HEADER = /^(max|max points|out of|total points|possible)$/i;
var CATEGORY_HEADER = /category|type/i;
var IGNORE_SEL = '.MuiBadge-badge, .MuiAvatar-root, .MuiTouchRipple-root, [aria-hidden="true"], svg, button';
var TABLE_SEL = "table, .MuiTable-root, [role='table'], [role='grid']";
var CARD_GRADE_RE = /(?:^|\s)Name\s*:\s*(.+?)\s*(?=(?:Max|Maximum|Out of)\s*:)(?:Max|Maximum|Out of)\s*:\s*(\d+(?:\.\d+)?)\s*(?=(?:Score|Mark|Grade)\s*:)(?:Score|Mark|Grade)\s*:\s*(\d+(?:\.\d+)?|[A-F][+-]?)/i;
var CARD_UNGRADED_RE = /(?:^|\s)Name\s*:\s*(.+?)\s*(?:(?:Max|Maximum|Out of)\s*:\s*(\d+(?:\.\d+)?)\s*)?(?:Ungraded|Not graded|Pending)(?:\s|$)/i;
var ROW_SEL = "tr, [role='row']";
var CELL_SEL = "td, th, [role='cell'], [role='gridcell'], [role='columnheader']";

function textOf(el) { return (el.textContent || "").replace(/\s+/g, " ").trim(); }
function hiddenStyle(el) {
  var st = getComputedStyle(el);
  return st.display === "none" || st.visibility === "hidden" || Number(st.opacity) === 0;
}
function visible(el) {
  if (!el) return false;
  if (el.closest('[aria-hidden="true"]')) return false;
  if (hiddenStyle(el)) return false;
  var r = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
  return !!el.offsetParent || !!(r && (r.width > 0 || r.height > 0)) || el === document.body || el === document.documentElement;
}

function classify(text) {
  var m = text.match(SCORE_MAX);
  if (m) {
    var s = parseFloat(m[1]), x = parseFloat(m[2]);
    if (s >= 0 && x > 0 && x < 100000 && s <= x * 10) return { kind: "score", score: s, max: x, percentage: Math.round(s / x * 1000) / 10 };
  }
  m = text.match(PCT);
  if (m) { var p = parseFloat(m[1]); if (p >= 0 && p <= 1000) return { kind: "pct", percentage: p }; }
  m = text.match(LETTER);
  if (m) return { kind: "letter", letter: m[1].toUpperCase() };
  return null;
}

// Visible text of a cell, excluding badges, avatars, counters, icons, buttons, hidden and aria-hidden nodes.
// Chips are kept only when they contain a grade-shaped value (e.g. a letter-grade chip).
function cellText(el) {
  var out = "";
  for (var i = 0; i < el.childNodes.length; i++) {
    var n = el.childNodes[i];
    if (n.nodeType === 3) { out += n.nodeValue; continue; }
    if (n.nodeType !== 1) continue;
    if (hiddenStyle(n)) continue;
    if (n.matches(".MuiChip-root")) { var ct = textOf(n); if (classify(ct)) out += " " + ct; continue; }
    if (n.matches(IGNORE_SEL)) continue;
    out += " " + cellText(n);
  }
  return out.replace(/\s+/g, " ").trim();
}

function rowCells(r) { return Array.prototype.slice.call(r.querySelectorAll(CELL_SEL)); }
function isHeaderRow(r, cells) {
  if (r.closest("thead")) return true;
  return cells.length > 0 && cells.every(function (c) { return c.tagName === "TH" || c.getAttribute("role") === "columnheader"; });
}

function headerInfo(table, cache) {
  if (cache.has(table)) return cache.get(table);
  var info = { labels: [], weightCols: {}, scoreCols: {}, pctCols: {}, maxCols: {}, catCols: {} };
  var rows = Array.prototype.slice.call(table.querySelectorAll(ROW_SEL));
  for (var i = 0; i < rows.length; i++) {
    var cells = rowCells(rows[i]);
    if (!cells.length) continue;
    if (!isHeaderRow(rows[i], cells)) break;
    info.labels = cells.map(cellText);
    info.labels.forEach(function (l, j) {
      if (WEIGHT_HEADER.test(l)) info.weightCols[j] = true;
      else if (MAX_HEADER.test(l)) info.maxCols[j] = true;
      else if (PCT_HEADER.test(l)) info.pctCols[j] = true;
      else if (SCORE_HEADER.test(l)) info.scoreCols[j] = true;
      if (CATEGORY_HEADER.test(l)) info.catCols[j] = true;
    });
    break;
  }
  cache.set(table, info);
  return info;
}



function parseIvyGradeCardStructure(items, courseLevel, d, seen) {
  // Live Ivy cards may render Name/Max/Score as separate nested elements.
  // Find a small visible ancestor containing all three labeled values.
  var roots = Array.prototype.slice.call(document.querySelectorAll("div, section, article, li"));
  roots.forEach(function (root) {
    if (!visible(root)) return;
    if (root.closest(TABLE_SEL)) return;
    var txt = cellText(root);
    if (!txt || txt.length > 500 || !/\bName\s*:/i.test(txt) || !/\b(?:Max|Maximum|Out of)\s*:/i.test(txt) || !/\b(?:Score|Mark|Grade)\s*:/i.test(txt)) return;

    var nm = txt.match(/\bName\s*:\s*(.*?)\s*(?=(?:Max|Maximum|Out of)\s*:)/i);
    var mm = txt.match(/\b(?:Max|Maximum|Out of)\s*:\s*(\d+(?:\.\d+)?)/i);
    var sm = txt.match(/\b(?:Score|Mark|Grade)\s*:\s*(\d+(?:\.\d+)?|[A-F][+-]?)/i);
    if (!nm || !mm || !sm) return;
    var name = nm[1].replace(/\s+/g, " ").trim();
    var max = parseFloat(mm[1]);
    var raw = sm[1].trim();
    if (!name || !isFinite(max) || max <= 0) return;

    // Prefer the smallest ancestor containing all three labels.
    var child = root.firstElementChild;
    if (child && root.childElementCount > 1) {
      var smaller = null;
      Array.prototype.slice.call(root.children).forEach(function (c) {
        if (!visible(c) || c.closest(TABLE_SEL)) return;
        var ct = cellText(c);
        if (ct && ct.length <= txt.length && /\bName\s*:/i.test(ct) && /\b(?:Max|Maximum|Out of)\s*:/i.test(ct) && /\b(?:Score|Mark|Grade)\s*:/i.test(ct)) smaller = c;
      });
      if (smaller) return; // let the smaller matching ancestor be processed
    }

    var g = classify(raw);
    if (!g) {
      var score = parseFloat(raw);
      if (!isFinite(score)) return;
      g = { kind: "score", score: score, max: max, percentage: Math.round(score / max * 1000) / 10 };
    } else if (g.kind === "score") {
      g.max = max;
      g.percentage = Math.round(g.score / max * 1000) / 10;
    }
    var key = name.toLowerCase() + "|" + (g.score != null ? g.score : "") + "|" + max + "|" + (g.letter || "");
    if (seen[key]) return;
    seen[key] = true;

    d.candidateRows++;
    d.acceptedRows++;
    d.gradeElementCount++;
    d.gradeCardCount++;
    if (d.gradeSamples.length < 8) d.gradeSamples.push({ name: name.slice(0, 60), grade: raw + "/" + max });
    var rec = {
      label: name,
      score: g.kind === "score" ? g.score : null,
      max: max,
      percentage: g.percentage != null ? g.percentage : null,
      letter: g.letter || null,
      source: "ivy-mui-grade-card-structure",
      sourceUrl: location.href
    };
    if (COURSE_LEVEL.test(name)) {
      d.courseLevelRows++;
      courseLevel.push(rec);
    } else {
      items.push({ name: name, category: null, score: rec.score, max: rec.max, percentage: rec.percentage, letter: rec.letter, graded: true, sourceUrl: location.href });
    }
  });
}

function parseIvyGradeCards(items, courseLevel, d, sharedSeen) {
  // Ivy's live GradeBook can render grading entries as MUI cards rather than <table> rows.
  // Example observed in the live DOM:
  // "Name: Overall Max: 100 Score:79.73"
  var seen = sharedSeen || {};
  var all = Array.prototype.slice.call(document.querySelectorAll("div, section, article, li, td, span"));
  var matches = [];
  all.forEach(function (el) {
    if (!visible(el)) return;
    if (el.closest(TABLE_SEL)) return;
    var t = cellText(el);
    if (!t || t.length > 350) return;
    var m = t.match(CARD_GRADE_RE);
    if (m) matches.push({ el: el, text: t, m: m });
    else {
      var u = t.match(CARD_UNGRADED_RE);
      if (u) matches.push({ el: el, text: t, u: u });
    }
  });

  // Prefer the smallest matching elements to avoid parsing the same card repeatedly
  // through its parent containers.
  matches = matches.filter(function (x) {
    return !matches.some(function (y) {
      return y !== x && x.el.contains(y.el);
    });
  });

  matches.forEach(function (x) {
    if (x.m) {
      var name = x.m[1].replace(/\s+/g, " ").trim();
      var max = parseFloat(x.m[2]);
      var raw = x.m[3].trim();
      var g = classify(raw);
      // classify("79.73") is not a grade by itself, so treat it as a score.
      if (!g) {
        var score = parseFloat(raw);
        if (isFinite(score) && max > 0) {
          g = { kind: "score", score: score, max: max, percentage: Math.round(score / max * 1000) / 10 };
        }
      }
      if (!g || !name) return;

      var key = name.toLowerCase() + "|" + (g.score != null ? g.score : "") + "|" + max + "|" + (g.letter || "");
      if (seen[key]) return;
      seen[key] = true;

      d.candidateRows++;
      d.acceptedRows++;
      d.gradeElementCount++;
      if (d.gradeSamples.length < 8) d.gradeSamples.push({ name: name.slice(0, 60), grade: raw + "/" + max });

      var rec = {
        label: name,
        score: g.kind === "score" ? g.score : null,
        max: g.kind === "score" ? g.max : max,
        percentage: g.percentage != null ? g.percentage : null,
        letter: g.letter || null,
        source: "ivy-mui-grade-card",
        sourceUrl: location.href
      };

      if (COURSE_LEVEL.test(name)) {
        d.courseLevelRows++;
        courseLevel.push(rec);
      } else {
        items.push({
          name: name,
          category: null,
          score: rec.score,
          max: rec.max,
          percentage: rec.percentage,
          letter: rec.letter,
          graded: true,
          sourceUrl: location.href
        });
      }
    } else if (x.u) {
      var uname = x.u[1].replace(/\s+/g, " ").trim();
      if (!uname) return;
      var key2 = uname.toLowerCase() + "|ungraded";
      if (seen[key2]) return;
      seen[key2] = true;
      d.candidateRows++;
      d.acceptedRows++;
      d.ungradedRows++;
      items.push({
        name: uname,
        category: null,
        score: null,
        max: x.u[2] ? parseFloat(x.u[2]) : null,
        percentage: null,
        letter: null,
        graded: false,
        sourceUrl: location.href
      });
      if (d.gradeSamples.length < 8) d.gradeSamples.push({ name: uname.slice(0, 60), grade: "(ungraded)" });
    }
  });

  if (matches.length) {
    d.strategy = "ivy-mui-table-rows + ivy-mui-grade-cards + page-summary";
    d.gradeCardCount = matches.length;
  }
}

function extractCourseName() {
  var candidates = [];
  var bad = /^(grade\s*book|grades?|grading|courses?|dashboard|home|overview)$/i;
  Array.prototype.slice.call(document.querySelectorAll("h1, h2, h3, h4, h5, h6, [role='heading'], [aria-current='page'], .MuiBreadcrumbs-li"))
    .forEach(function (el) {
      if (!visible(el)) return;
      var t = cellText(el).replace(/^#\s*/, "").replace(/\s+/g, " ").trim();
      if (!t || t.length < 3 || t.length > 140 || bad.test(t)) return;
      if (/gradebook|grading/i.test(t)) return;
      candidates.push(t);
    });
  // Last-resort: Ivy has been observed rendering the course title as a text
  // block such as "# Language Arts-10-STEM : Gr10-B".
  Array.prototype.slice.call(document.querySelectorAll("p, span, div, li")).forEach(function (el) {
    if (!visible(el) || el.children.length > 4) return;
    var t = cellText(el).replace(/^#\s*/, "").replace(/\s+/g, " ").trim();
    if (!/^.{2,100}\s*:\s*.{1,80}$/.test(t) || /gradebook|grading/i.test(t)) return;
    if (t.length <= 140) candidates.push(t);
  });
  var distinctive = candidates.find(function (t) {
    return /:\s*[^:]+$/.test(t) && !/ivy\\s+stem\\s+international\\s+schools/i.test(t);
  });
  if (distinctive) return distinctive;
  var nonSite = candidates.find(function (t) {
    return !/ivy\\s+stem\\s+international\\s+schools/i.test(t);
  });
  return nonSite || (candidates.length ? candidates[0] : null);
}

function parse() {
  var t0 = Date.now();
  var d = {
    parserId: "ivy-gradebook", strategy: "ivy-mui-table-rows + page-summary",
    tableCount: 0, tablesScanned: 0, headerRows: 0, candidateRows: 0, acceptedRows: 0,
    ungradedRows: 0, courseLevelRows: 0, gradeElementCount: 0, gradeCardCount: 0, weightCellsIgnored: 0, hiddenRowsIgnored: 0,
    headers: [], gradeSamples: [], ignoredSamples: [], warnings: [], errors: [], readMs: 0
  };
  var tables = Array.prototype.slice.call(document.querySelectorAll(TABLE_SEL));
  d.tableCount = tables.length;
  if (!tables.length) d.warnings.push("No table elements found on the GradeBook page");

  var owner = new Map();
  tables.forEach(function (t) {
    var rows = Array.prototype.slice.call(t.querySelectorAll(ROW_SEL));
    if (rows.length) d.tablesScanned++;
    rows.forEach(function (r) { if (!owner.has(r)) owner.set(r, t); });
  });

  var cache = new Map();
  var items = [], courseLevel = [];

  owner.forEach(function (table, row) {
    if (row.closest(".MuiTablePagination-root, tfoot")) return;
    if (!visible(row)) { d.hiddenRowsIgnored++; return; }
    var cells = rowCells(row);
    if (!cells.length) return;
    if (isHeaderRow(row, cells)) { d.headerRows++; return; }
    var hi = headerInfo(table, cache);
    if (hi.labels.length && d.headers.length < 4) d.headers.push(hi.labels.join(" | "));
    d.candidateRows++;
    var texts = cells.map(function (c) { return visible(c) ? cellText(c) : ""; });

    var grades = [], maxVal = null, i, g;
    for (i = 0; i < texts.length; i++) {
      if (hi.maxCols[i] && BARE_NUM.test(texts[i])) maxVal = parseFloat(texts[i]);
    }
    for (i = 0; i < texts.length; i++) {
      if (!texts[i]) continue;
      if (hi.weightCols[i]) { if (classify(texts[i]) || BARE_NUM.test(texts[i])) d.weightCellsIgnored++; continue; }
      if (hi.maxCols[i]) continue;
      g = classify(texts[i]);
      if (!g && BARE_NUM.test(texts[i])) {
        var n = parseFloat(texts[i]);
        if (hi.pctCols[i]) g = { kind: "pct", percentage: n };
        else if (hi.scoreCols[i]) g = { kind: "score", score: n, max: maxVal, percentage: maxVal ? Math.round(n / maxVal * 1000) / 10 : null };
      }
      if (g) { g.index = i; grades.push(g); d.gradeElementCount++; }
    }

    var name = null, category = null;
    for (i = 0; i < texts.length; i++) {
      var t = texts[i];
      if (!t || t.length > 120) continue;
      if (grades.some(function (gr) { return gr.index === i; })) continue;
      if (hi.weightCols[i] || hi.maxCols[i]) continue;
      if (hi.catCols[i]) { if (!category) category = t; continue; }
      if (!/[A-Za-z\u0600-\u06FF]{2,}/.test(t)) continue;
      if (NON_NAME.test(t)) continue;
      if (name == null) name = t;
    }
    if (!category && name && CATEGORY_RE.test(name)) category = name.match(CATEGORY_RE)[0];

    if (!name) {
      if (d.ignoredSamples.length < 8) d.ignoredSamples.push(texts.join(" | ").slice(0, 90));
      return;
    }

    if (!grades.length) {
      var headerLike = texts.length >= 3 && texts.every(function (x) { return !x || HEADERISH.test(x); });
      if (headerLike) return;
      if (COURSE_LEVEL.test(name)) return; // empty total row: no value -> not a grade
      d.ungradedRows++; d.acceptedRows++;
      items.push({ name: name, category: category, score: null, max: null, percentage: null, letter: null, graded: false, sourceUrl: location.href });
      if (d.gradeSamples.length < 8) d.gradeSamples.push({ name: name.slice(0, 60), grade: "(ungraded)" });
      return;
    }

    var sc = grades.filter(function (x) { return x.kind === "score"; })[0];
    var pc = grades.filter(function (x) { return x.kind === "pct"; })[0];
    var lt = grades.filter(function (x) { return x.kind === "letter"; })[0];
    var rec = {
      score: sc ? sc.score : null,
      max: sc ? sc.max : null,
      percentage: pc ? pc.percentage : (sc ? sc.percentage : null),
      letter: lt ? lt.letter : null
    };
    d.acceptedRows++;
    if (d.gradeSamples.length < 8) d.gradeSamples.push({ name: name.slice(0, 60), grade: grades.map(function (x) { return texts[x.index]; }).join(" ") });

    if (COURSE_LEVEL.test(name)) {
      d.courseLevelRows++;
      courseLevel.push({ label: name, score: rec.score, max: rec.max, percentage: rec.percentage, letter: rec.letter, source: "gradebook-row", sourceUrl: location.href });
    } else {
      items.push({ name: name, category: category, score: rec.score, max: rec.max, percentage: rec.percentage, letter: rec.letter, graded: true, sourceUrl: location.href });
    }
  });

  // Ivy also renders live GradeBook entries as Material UI cards, not tables.
  var cardSeen = {};
  parseIvyGradeCardStructure(items, courseLevel, d, cardSeen);
  parseIvyGradeCards(items, courseLevel, d, cardSeen);

  // Course-level grade shown outside the table (e.g. "Course Grade: B+" summary).
  var seen = {};
  Array.prototype.slice.call(document.querySelectorAll("h1, h2, h3, h4, h5, h6, p, span, div, strong, b, li")).forEach(function (el) {
    if (el.closest(TABLE_SEL)) return;
    if (el.children.length > 4) return;
    if (!visible(el)) return;
    var t = cellText(el);
    if (!t || t.length > 60) return;
    var m = t.match(SUMMARY_RE);
    if (!m) return;
    var g2 = classify(m[3]);
    if (!g2) return;
    var key = (m[1] + " " + (m[2] || "")).trim().toLowerCase() + "=" + m[3].trim();
    if (seen[key]) return;
    seen[key] = true;
    d.courseLevelRows++;
    courseLevel.push({
      label: (m[1] + " " + (m[2] || "")).trim(),
      score: g2.kind === "score" ? g2.score : null, max: g2.kind === "score" ? g2.max : null,
      percentage: g2.percentage != null ? g2.percentage : null, letter: g2.letter || null,
      source: "page-summary", sourceUrl: location.href
    });
  });

  d.readMs = Date.now() - t0;
  var courseName = extractCourseName();
  return { items: items, courseLevel: courseLevel, courseName: courseName, diagnostics: d };
}

window.IvyParser = { parse: parse, parserId: "ivy-gradebook", cellText: cellText, classify: classify };
})();
