(function () {
"use strict";

const store = chrome.storage.local;
const main = document.getElementById("main");
let settings, lastScan, prevScan, history, progress, quarterScans = {}, studentInfo = {}, courseCatalog = [];
let sortKey = "name", sortDir = 1, filterKey = "all";
let quarterView = "1";
let discoveryComplete = false, allGradesScanned = false;

function esc(v) { const d = document.createElement("div"); d.textContent = v == null ? "" : String(v); return d.innerHTML; }
function fPct(v) { return v == null ? "—" : (Math.round(v * 10) / 10) + "%"; }
function fNum(v) { return v == null ? "—" : Number(v).toFixed(2); }
function performanceLevel(pct, letter) {
  const p = pct == null ? null : Number(pct);
  const l = String(letter || "").trim().toUpperCase();
  if ((p != null && p >= 90) || ["A+","A","A-"].includes(l)) return { label: "Excellent", cls: "excellent" };
  if ((p != null && p >= 80) || ["B+","B","B-"].includes(l)) return { label: "Good", cls: "good" };
  if ((p != null && p >= 70) || ["C+","C","C-"].includes(l)) return { label: "Fair", cls: "fair" };
  if ((p != null && p >= 60) || ["D+","D","D-"].includes(l)) return { label: "Bad", cls: "bad" };
  if (p != null || l === "F") return { label: "Very Bad", cls: "very-bad" };
  return { label: "—", cls: "gray" };
}
function performanceBadge(pct, letter) {
  const level = performanceLevel(pct, letter);
  return badge(level.label, level.cls);
}
function itemStatus(it) {
  const assessment = isAssessmentItem(it);
  const zero = it && it.graded && ((it.percentage != null && Number(it.percentage) === 0) || (it.score != null && Number(it.score) === 0));
  if (zero && assessment) return { label: "Not started", cls: "yellow" };
  if (it && it.missing) return { label: "Missing", cls: "yellow" };
  if (it && it.graded) {
    const level = performanceLevel(it.percentage, it.letter);
    return { label: level.label, cls: level.cls };
  }
  return { label: "Not graded", cls: "gray" };
}
function gradeScaleHtml() {
  const bands = [["93–100","A","Excellent"],["90–92","A-","Excellent"],["87–89","B+","Good"],["83–86","B","Good"],["80–82","B-","Good"],["77–79","C+","Fair"],["73–76","C","Fair"],["70–72","C-","Fair"],["67–69","D+","Bad"],["63–66","D","Bad"],["60–62","D-","Bad"],["0–59","F","Very Bad"]];
  return '<div class="grade-scale"><div class="grade-scale-title">Grade Scale</div><div class="grade-scale-grid">' + bands.map(b => '<div class="grade-scale-cell"><b>' + b[0] + '=</b><span>' + b[1] + '</span><small>' + b[2] + '</small></div>').join('') + '</div></div>';
}
function fmtDate(ts) { return ts ? new Date(ts).toLocaleString() : "—"; }
function badge(txt, cls) { return '<span class="badge ' + cls + '">' + esc(txt) + "</span>"; }
const STATE_FROM_STATUS = { ok: "SUCCESS", empty: "SUCCESS_EMPTY", failed: "FAILED_OTHER", skipped: "SKIPPED" };
function stateOf(c) { return c.state || STATE_FROM_STATUS[c.status] || "PENDING"; }
function stateBadge(c) {
  const st = stateOf(c);
  return badge(st, st === "SUCCESS" ? "green" : st.indexOf("FAILED") === 0 ? "red" : "gray");
}
function kvRow(k, v) { return '<div class="kv"><span>' + esc(k) + "</span><b>" + esc(v) + "</b></div>"; }
function scanningPhase(p) { return p && (p.phase === "scanning" || p.phase === "starting" || p.phase === "discovering"); }

// Safely normalize the course identity used by the Details page.
function courseParts(c) {
  const subject = c && (c.subject || c.displayName || c.name) || "Unknown subject";
  const section = c && c.section ? String(c.section) : "";
  return { subject: String(subject), section: section };
}

// Quarter rows are course-level data, not tickets/assessments.
function isQuarterRow(it) {
  return /^quarter\s+[1-4]$/i.test(String(it && it.name || "").trim());
}

// Only true assessment/work items can be "Not started" when their grade is 0.
function isAssessmentItem(it) {
  if (!it || isQuarterRow(it)) return false;
  const text = String((it.category || "") + " " + (it.name || ""))
    .toLowerCase().replace(/\s+/g, " ").trim();
  if (/\b(participation|behavior|behaviour|conduct|attitude|discipline|engagement|effort|citizenship|portfolio)\b/.test(text)) return false;
  return /\b(quiz|quizzes|wka|h\.?\s*w\.?|homework|assignment|assignments|ext(?:ra)?|ext\s+ticket|worksheet|classwork|assessment|test|tests|exam|exams|quarter\s+exam|project|projects|lab|labs|essay|presentation|task|tasks|cba|oth)\b/.test(text);
}

function gradingItems(c) {
  return (c && c.items || []).filter(it => !isQuarterRow(it));
}

// The LMS can expose several quarters in one GradeBook. A selected quarter is strict:
// only records explicitly belonging to that quarter are shown. Quarter-neutral records
// are not shown because they can leak data from a quarter that has not started.
function filterScanToQuarter(scan, quarter) {
  if (!scan) return null;
  const q = Number(quarter || 1);
  const marker = new RegExp('\\b(?:quarter\\s*|q)'+q+'\\b', 'i');
  const keep = (item) => {
    const text = String((item && (item.name || item.label || item.category)) || '');
    return marker.test(text);
  };
  const copy = Object.assign({}, scan);
  copy.courses = (scan.courses || []).map(c => {
    const cc = Object.assign({}, c);
    if (Array.isArray(c.items)) cc.items = c.items.filter(keep);
    if (Array.isArray(c.courseLevel)) cc.courseLevel = c.courseLevel.filter(keep);
    return cc;
  });
  return copy;
}

async function refresh() {
  const st = await store.get(["gdSettings", "gdLastScan", "gdPrevScan", "gdScanHistory", "gdProgress", "gdQuarterScans", "gdDiscoveryComplete", "gdAllGradesScanned", "gdCourseCatalog", "gdStudentInfo"]);
  settings = GD.mergeSettings(st.gdSettings || {});
  quarterView = String((st.gdSettings || {}).quarterView || (st.gdSettings || {}).activeQuarter || 1);
  // Previous-grade comparisons stay within the selected quarter; do not reuse another quarter.\n  prevScan = null;
  history = st.gdScanHistory || [];
  progress = st.gdProgress || null;
  quarterScans = st.gdQuarterScans || {};
  studentInfo = st.gdStudentInfo || {};
  courseCatalog = st.gdCourseCatalog || [];
  discoveryComplete = !!st.gdDiscoveryComplete;
  allGradesScanned = quarterView === "all" ? !!st.gdAllGradesScanned : !!quarterScans[String(settings.activeQuarter)];
  // A selected quarter is strictly isolated. Never fall back to another
  // quarter's scan or to the global last scan. Also remove explicitly labeled
  // records from other quarters if an older scan was saved before this filter.
  lastScan = quarterView === "all" ? (st.gdLastScan || null) : filterScanToQuarter(quarterScans[String(settings.activeQuarter)] || null, settings.activeQuarter);
  updateBanner();
  route();
}

function courseGrade(c) {
  const q = Number(settings && settings.activeQuarter || c && c.quarter || 0);
  if (q) {
    const marker = new RegExp('^\\s*(?:quarter\\s*|q)' + q + '\\s*$', 'i');
    const qr = (Array.isArray(c && c.items) ? c.items : []).filter(t => marker.test(String((t && (t.name || t.label)) || '').trim()));
    for (const t of qr) if (t && t.percentage != null) return { pct: Number(t.percentage), letter: t.letter || null, label: t.name || t.label || ('Quarter ' + q), source: 'LMS-provided' };
    for (const t of qr) if (t && t.score != null && Number(t.max)) return { pct: Math.round(Number(t.score) / Number(t.max) * 1000) / 10, letter: t.letter || null, label: t.name || t.label || ('Quarter ' + q), source: 'LMS-provided' };
  }
  const cl = Array.isArray(c && c.courseLevel) ? c.courseLevel : [];
  const overall = cl.find(t => {
    const label = String((t && (t.label || t.name)) || "").trim().toLowerCase();
    return label === "overall" || label === "course grade" || label === "final grade" || label === "total";
  });
  const rows = overall ? [overall] : cl;
  for (const t of rows) if (t && t.percentage != null) return { pct: Number(t.percentage), letter: t.letter || null, label: t.label || t.name || "Overall", source: "LMS-provided" };
  for (const t of rows) if (t && t.score != null && Number(t.max)) return { pct: Math.round(Number(t.score) / Number(t.max) * 1000) / 10, letter: t.letter || null, label: t.label || t.name || "Overall", source: "LMS-provided" };
  return { pct: null, letter: null, label: null, source: "unavailable" };
}

function derive(c) {
  const g = courseGrade(c);
  const letter = g.letter || (g.pct != null ? GD.percentToLetter(g.pct, settings.percentBands) : null);
  const cls = GD.courseClass(c, settings);
  const points = cls === "main" && letter ? GD.letterToPoints(letter, settings.letterMap) : null;
  const w = GD.courseWeight(c, settings);
  let graded = 0, ungraded = 0; const ungradedNames = [];
  gradingItems(c).forEach(it => { if (it.graded) graded++; else { ungraded++; ungradedNames.push(it.name); } });
  let prevPct = null;
  if (prevScan) for (const p of (prevScan.courses || [])) if (p.id === c.id) prevPct = courseGrade(p).pct;
  const auto = !(settings.classOverride && settings.classOverride[c.id]);
  return {
    pct: g.pct, letter: letter,
    letterSource: g.letter ? "LMS-provided letter" : (g.pct != null ? "GPA Track estimate" : null),
    gradeLabel: g.label, gradeSource: g.source,
    cls: cls, clsLabel: cls === "main" ? (auto ? "Likely GPA-relevant" : "GPA: Main (manual)") : (auto ? "GPA relevance unknown" : "Other (manual)"),
    auto: auto, points: points, weight: w.w, weightKind: w.kind,
    graded: graded, ungraded: ungraded, ungradedNames: ungradedNames,
    included: cls === "main" && !settings.excluded[c.id] && points != null,
    prevPct: prevPct, status: c.status, error: c.error, note: c.note
  };
}

function route() {
  const m = (location.hash || "").match(/^#\/course\/(.+)$/);
  if (m) renderCourse(m[1]); else renderOverview();
}
window.addEventListener("hashchange", route);

// ============================ OVERVIEW ============================
function studentInfoHtml() {
  const name = studentInfo.name || "";
  const grade = studentInfo.grade || "";
  const id = studentInfo.schoolId || "";
  return '<div class="card student-info-card" style="margin-bottom:16px">' +
    '<div class="calc-row" style="justify-content:space-between;align-items:center">' +
    '<div><h2 style="margin:0">Student Information</h2><div class="muted">Add your name, grade, and School ID. This is information only — there is no school-account login.</div></div>' +
    '</div>' +
    '<div class="calc-row">' +
    '<label class="inline">Name <input type="text" id="student-name" value="' + esc(name) + '" placeholder="Student name"></label>' +
    '<label class="inline">Grade <input type="text" id="student-grade" value="' + esc(grade) + '" placeholder="Grade"></label>' +
    '<label class="inline">School ID <input type="text" id="student-school-id" value="' + esc(id) + '" placeholder="School ID"></label>' +
    '<button id="save-student-info" class="primary">Save</button>' +
    '<span id="student-info-note" class="muted"></span>' +
    '</div></div>';
}
function bindStudentInfo() {
  const save = document.getElementById("save-student-info");
  if (!save) return;
  save.addEventListener("click", async () => {
    studentInfo = {
      name: (document.getElementById("student-name").value || "").trim(),
      grade: (document.getElementById("student-grade").value || "").trim(),
      schoolId: (document.getElementById("student-school-id").value || "").trim()
    };
    await store.set({ gdStudentInfo: studentInfo });
    const note = document.getElementById("student-info-note");
    if (note) {
      note.textContent = "Saved.";
      setTimeout(() => { if (note) note.textContent = ""; }, 1800);
    }
  });
}
function activeQuarterKey() { return String(settings.activeQuarter || 1); }
function quarterLocked(q) { return false; }
function availableQuarterScans() {
  return [1,2,3,4].map(q => ({ q, scan: filterScanToQuarter(quarterScans[String(q)] || null, q) })).filter(x => x.scan);
}
function ticketAnalysis(c) {
  const groups = {
    participation_behavior:{label:"Participation & Behavior",graded:0,sum:0,count:0,missing:0,notStarted:0},
    assignment_assessment:{label:"Assignments & Assessments",graded:0,sum:0,count:0,missing:0,notStarted:0},
    other:{label:"Other",graded:0,sum:0,count:0,missing:0,notStarted:0}
  };
  gradingItems(c).forEach(it => {
    const text = ((it.category || "") + " " + (it.name || "")).toLowerCase();
    const k = /participation|behavior|behaviour|conduct|attitude|discipline|engagement|effort|citizenship/.test(text) ? "participation_behavior" : isAssessmentItem(it) ? "assignment_assessment" : "other";
    const g = groups[k];
    const zeroGrade = it.graded && (Number(it.score) === 0 || Number(it.percentage) === 0);
    if (zeroGrade && isAssessmentItem(it)) { g.notStarted++; return; }
    if (it.missing) { g.missing++; return; }
    if (it.graded && it.percentage != null) { g.graded++; g.sum += Number(it.percentage); g.count++; }
  });
  Object.keys(groups).forEach(k => groups[k].average = groups[k].count ? Math.round(groups[k].sum / groups[k].count * 10) / 10 : null);
  return groups;
}

function weaknessReason(c) {
  const a = ticketAnalysis(c);
  const parts = [];
  if (a.participation_behavior.count && a.participation_behavior.average < settings.minPercent) parts.push(a.participation_behavior.label + " average " + fPct(a.participation_behavior.average));
  if (a.assignment_assessment.count && a.assignment_assessment.average < settings.minPercent) parts.push(a.assignment_assessment.label + " average " + fPct(a.assignment_assessment.average));
  const lowItems = gradingItems(c).filter(it => it.graded && it.percentage != null && Number(it.percentage) > 0 && Number(it.percentage) < Number(settings.minPercent));
  if (lowItems.length) parts.push(lowItems.length + " graded item(s) below " + settings.minPercent + "%");
  const notStarted = gradingItems(c).filter(it => it.graded && isAssessmentItem(it) && (Number(it.score) === 0 || Number(it.percentage) === 0));
  if (notStarted.length) parts.push(notStarted.length + " item(s) not started");
  return parts;
}

function quarterSelectorHtml() {
  let h = '<div class="card" style="margin-bottom:16px"><div class="calc-row" style="justify-content:space-between;align-items:center">' +
    '<div><h2 style="margin:0">Academic Quarter</h2><div class="muted">Choose which quarter to view and scan. Previous quarters remain available and are never locked or reset.</div></div>' +
    '<label class="inline">Quarter <select id="quarter-select">';
  for (let q=1;q<=4;q++) h += '<option value="'+q+'" '+(quarterView===String(q)?'selected':'')+'>Quarter '+q+'</option>';
  h += '<option value="all" '+(quarterView==="all"?'selected':'')+'>All Quarters</option>';
  h += '</select></label></div></div>';
  return h;
}
function subjectSelectionHtml(courses) {
  const q = activeQuarterKey(), selected = Array.isArray(settings.selectedGpaSubjects && settings.selectedGpaSubjects[q]) ? settings.selectedGpaSubjects[q] : [];

  let h = '<div class="card" style="margin-bottom:16px"><h2>Select GPA Subjects</h2><div class="muted">GPA Track found <b>'+courses.length+'</b> course(s). Select only the subjects that should count toward your GPA for Quarter '+q+'. Other courses remain visible but do not affect GPA.</div><div class="grid cols-2" style="margin-top:10px">';
  courses.forEach(c => { h += '<label class="inline"><input type="checkbox" class="gpa-subject" data-id="'+esc(c.id)+'" '+(selected.indexOf(String(c.id))!==-1?'checked':'')+'> '+esc(c.subject || c.name || 'Unknown subject')+(c.section?' <span class="muted">— '+esc(c.section)+'</span>':'')+'</label>'; });
  h += '</div><button id="save-gpa-subjects" style="margin-top:12px">Save GPA Subjects</button><span id="gpa-save-note" class="muted" style="margin-left:8px"></span></div>';
  return h;
}
function bindQuarterControls(courses) {
  const qsel = document.getElementById('quarter-select');
  if (qsel) qsel.addEventListener('change', async e => {
    const value = String(e.target.value);
    quarterView = value;
    if (value !== "all") settings.activeQuarter = Number(value);
    settings.quarterView = value;
    await store.set({ gdSettings: settings });
    refresh();
  });
  const save = document.getElementById('save-gpa-subjects');
  if (save) save.addEventListener('click', async () => {
    const q = activeQuarterKey();
    settings.selectedGpaSubjects[q] = Array.from(document.querySelectorAll('.gpa-subject:checked')).map(x => String(x.dataset.id));
    await store.set({ gdSettings: settings });
    const note = document.getElementById('gpa-save-note'); if (note) note.textContent = 'Saved.';
    refresh();
  });
}
function renderAllQuarters() {
  const entries = availableQuarterScans();
  let html = studentInfoHtml() + quarterSelectorHtml();
  html += '<div class="card"><h2>All Quarters</h2>';
  if (!entries.length) {
    html += '<div class="empty">No quarter scans are saved yet. Select a quarter and scan it; its grades and tickets will remain available here.</div></div>';
    main.innerHTML = html;
    bindStudentInfo();
    bindQuarterControls([]);
    return;
  }
  html += '<div class="muted" style="margin-bottom:12px">Saved quarter scans are shown separately. Changing quarters does not clear their grades or tickets.</div>';
  entries.forEach(({q, scan}) => {
    const courses = scan.courses || [];
    html += '<div class="card" style="margin-top:12px"><h3 style="margin-top:0">Quarter '+q+'</h3>';
    html += '<div class="kv"><span>Last scan</span><b>'+fmtDate(scan.timestamp)+'</b></div>';
    html += '<div class="kv"><span>Courses</span><b>'+courses.length+'</b></div>';
    html += '<div class="kv"><span>Scanned</span><b>'+(scan.succeeded + scan.failed)+' / '+scan.discovered+'</b></div>';
    html += '<table style="margin-top:8px"><thead><tr><th>Course</th><th class="num">Grade</th><th>Tickets</th></tr></thead><tbody>';
    courses.forEach(c => {
      const d = derive(c), ta = ticketAnalysis(c);
      const tickets = (c.items || []).length;
      const missing = (ta.participation_behavior?.missing || 0) + (ta.assignment_assessment?.missing || 0);
      html += '<tr><td>'+esc(c.subject || c.name || "Unknown subject")+'</td>' +
        '<td class="num">'+fPct(d.pct)+(d.letter ? ' ('+esc(d.letter)+')' : '')+'</td>' +
        '<td>'+tickets+(missing ? ' · '+missing+' missing' : '')+'</td></tr>';
    });
    html += '</tbody></table></div>';
  });
  html += '</div>';
  main.innerHTML = html;
  bindStudentInfo();
  bindQuarterControls([]);
}
function renderOverview() {
  if (quarterView === "all") { renderAllQuarters(); return; }
  if (!lastScan) {
    const catalog = Array.isArray(courseCatalog) ? courseCatalog : [];
    if (discoveryComplete && catalog.length) {
      main.innerHTML = studentInfoHtml() +
        '<div class="card"><h2>Quarter ' + esc(quarterView) + '</h2><div class="empty">No grades or tickets have been scanned for Quarter ' + esc(quarterView) + ' yet. Data from other quarters is not shown here.</div>' +
        '<button id="quarter-scan-all" class="primary">Scan All Grades for Quarter ' + esc(quarterView) + '</button></div>' +
        subjectSelectionHtml(catalog);
      bindStudentInfo();
      bindQuarterControls(catalog);
      const qs = document.getElementById("quarter-scan-all");
      if (qs) qs.addEventListener("click", () => chrome.runtime.sendMessage({type:"GD_SCAN_ALL_GRADES"}));
      return;
    }
    main.innerHTML = studentInfoHtml() + '<div class="card"><h2>Welcome to GPA Track</h2><div class="empty">First, click <b>Discover Courses</b>. The first scan only finds your courses and shows their names. Then choose which subjects count toward GPA and scan their grades.</div></div>';
    bindStudentInfo();
    showOnboarding();
    return;
  }
  if (discoveryComplete && lastScan.discoveryOnly) {
    const courses = lastScan.courses || [];
    main.innerHTML = studentInfoHtml() + '<div class="card"><h2>Your Courses</h2><div class="big">' + courses.length + '</div><div class="sub">courses detected. The names are shown below so you can choose your GPA subjects.</div></div>' + subjectSelectionHtml(courses) + '<div class="card"><h2>Next Step: Scan All Grades</h2><div class="empty">First scan <b>All Grades</b>. GPA calculation and the <b>Scan GPA Subjects</b> option will appear only after the full grade scan is completed.</div><button id="discovery-scan-all" class="primary">Scan All Grades</button></div>';
    bindStudentInfo();
    bindQuarterControls(courses);
    const ds = document.getElementById("discovery-scan-all");
    if (ds) ds.addEventListener("click", () => chrome.runtime.sendMessage({type:"GD_SCAN_ALL_GRADES"}));
    return;
  }
  const courses = lastScan.courses || [];
  if (discoveryComplete && !allGradesScanned) {
    main.innerHTML = studentInfoHtml() + '<div class="card"><h2>Scan All Grades First</h2><div class="empty">Your courses are ready. Select your GPA subjects, then scan <b>All Grades</b>. GPA and the <b>Scan GPA Subjects</b> option stay hidden until the full grade scan is completed.</div><button id="guard-scan-all" class="primary">Scan All Grades</button></div>' + subjectSelectionHtml(courses);
    bindStudentInfo();
    bindQuarterControls(courses);
    const gs = document.getElementById("guard-scan-all");
    if (gs) gs.addEventListener("click", () => chrome.runtime.sendMessage({type:"GD_SCAN_ALL_GRADES"}));
    return;
  }
  let quarterHtml = quarterSelectorHtml();
  let selectionHtml = subjectSelectionHtml(courses);
  const derived = courses.map(c => ({ c: c, d: derive(c) }));
  const gpa = GD.computeGpa(courses, settings);
  const gpaVal = gpa ? gpa.weighted : null;
  const health = GD.healthStatus(gpaVal, settings);

  const alerts = [];
  derived.forEach(x => {
    if (settings.alertLow && x.d.cls === "main" && x.d.pct != null && x.d.pct < settings.minPercent) {
      alerts.push({ type: "low", id: x.c.id, name: x.c.name, subject: x.c.subject || x.c.name, pct: x.d.pct, target: settings.minPercent });
    }
    if (settings.alertDrop && x.d.prevPct != null && x.d.pct != null && (x.d.prevPct - x.d.pct) >= settings.dropThreshold) {
      alerts.push({ type: "drop", name: x.c.name, from: x.d.prevPct, to: x.d.pct, delta: Math.round((x.d.pct - x.d.prevPct) * 10) / 10 });
    }
  });
  if (settings.alertUngraded) derived.forEach(x => {
    if (x.d.cls === "main" && x.d.ungraded >= settings.ungradedAlertMin) alerts.push({ type: "ungraded", name: x.c.name, count: x.d.ungraded, to: 1000 });
  });
  alerts.sort((a, b) => (a.type === "low" ? a.pct : a.to) - (b.type === "low" ? b.pct : b.to));

  const tgn = GD.targetGpaNeeded(courses, settings);
  const mainCourses = derived.filter(x => x.d.cls === "main");
  const otherCourses = derived.filter(x => x.d.cls !== "main");
  const ungradedTotal = derived.reduce((s, x) => s + x.d.ungraded, 0);
  const belowTarget = derived.filter(x => x.d.cls === "main" && x.d.pct != null && x.d.pct < settings.minPercent).length;
  const dropsCount = alerts.filter(a => a.type === "drop").length;

  let strongest = null, weakest = null;
  mainCourses.forEach(x => {
    if (x.d.pct == null) return;
    if (!strongest || x.d.pct > strongest.d.pct) strongest = x;
    if (!weakest || x.d.pct < weakest.d.pct) weakest = x;
  });

  const prevGpaEntry = history.length > 1 ? history[history.length - 2] : null;
  let html = studentInfoHtml() + quarterHtml + selectionHtml;

  html += '<div class="grid cols-2">';
  html += '<div class="card"><h2>GPA Summary</h2>';
  html += '<div class="big">' + (gpaVal != null ? fNum(gpaVal) : "—") + ' <span class="muted" style="font-size:16px">/ ' + fNum(settings.scaleMax) + '</span></div>';
  html += '<div class="sub">' + (gpa ? esc(gpa.label) : "Not enough GPA-relevant data yet") + "</div>";
  html += '<div style="margin-top:10px">' + health.emoji + " <b>" + esc(health.label) + "</b></div>";
  html += '<div style="margin-top:8px">' +
    '<div class="kv"><span>Target GPA</span><b>' + fNum(settings.targetGpa) + "</b></div>" +
    '<div class="kv"><span>Weighting</span><b>' + esc(gpa ? gpa.weighting : "Equal weighting") + "</b></div>" +
    '<div class="kv"><span>GPA-relevant courses</span><b>' + mainCourses.length + "</b></div>" +
    '<div class="kv"><span>Included in GPA</span><b>' + (gpa ? gpa.included : 0) + "</b></div>" +
    '<div class="kv"><span>Courses below target</span><b>' + belowTarget + "</b></div>" +
    '<div class="kv"><span>Ungraded items</span><b>' + ungradedTotal + "</b></div>" +
    "</div></div>";

  html += '<div class="card"><h2>Academic Health</h2>';
  html += '<div class="kv"><span>Current GPA</span><b>' + (gpaVal != null ? fNum(gpaVal) : "—") + "</b></div>";
  html += '<div class="kv"><span>Target GPA</span><b>' + fNum(settings.targetGpa) + "</b></div>";
  html += '<div class="kv"><span>Courses below target</span><b>' + belowTarget + "</b></div>";
  html += '<div class="kv"><span>Grade drops</span><b>' + dropsCount + "</b></div>";
  html += '<div class="kv"><span>Ungraded items</span><b>' + ungradedTotal + "</b></div>";
  html += '<div class="kv"><span>Highest performance</span><b>' + (strongest ? esc(strongest.c.name) + " — " + fPct(strongest.d.pct) : "—") + "</b></div>";
  html += '<div class="kv"><span>Lowest performance</span><b>' + (weakest ? esc(weakest.c.name) + " — " + fPct(weakest.d.pct) : "—") + "</b></div>";
  if (tgn && tgn.needed != null) {
    html += '<div class="alert blue" style="margin-top:10px">To reach a target GPA of <b>' + fNum(settings.targetGpa) + "</b>, your remaining GPA-subject average needs to be about <b>" + fNum(tgn.needed) + "</b> (" + esc(tgn.remainingNames.join(", ")) + "). GPA Track estimate.</div>";
  } else if (tgn && tgn.remainingCount && !tgn.currentCount) {
    html += '<div class="muted" style="margin-top:10px">Target GPA estimate unavailable: no graded GPA-relevant courses yet.</div>';
  }
  html += "</div></div>";

  html += '<div class="card" style="margin-top:16px"><h2>⚠️ Grade Levels <span class="pill muted">Core subjects below ' + settings.minPercent + "%, most urgent first</span></h2>";
  if (!alerts.length) html += '<div class="empty">All clear — no GPA alerts right now.</div>';
  alerts.forEach(a => {
    if (a.type === "low") {
      const gap = Math.round((a.target - a.pct) * 10) / 10;
      const c = derived.find(x => x.c.id === a.id)?.c || null;
      const reasons = c ? weaknessReason(c) : [];
      html += '<div class="alert red">⚠️ <b>Current performance in ' + esc(a.subject) + '</b> — Current: <b>' + fPct(a.pct) + '</b> · Target: <b>' + a.target + '%</b> · ' + gap + ' points below target.' + (reasons.length ? ' <span class="muted">Items affecting the result: ' + esc(reasons.join(' · ')) + '.</span>' : ' <span class="muted">Open View Tickets to see the items affecting the result.</span>') + '</div>';
    }
    else if (a.type === "drop") html += '<div class="alert yellow"><b>⚠️ Grade Drop · ' + esc(a.name) + "</b> — " + fPct(a.from) + " → " + fPct(a.to) + " (" + a.delta + " percentage points)</div>";
    else html += '<div class="alert blue"><b>Ungraded work · ' + esc(a.name) + "</b> — " + a.count + " ungraded item(s) in a GPA-relevant course. They are not counted as zero.</div>";
  });
  html += "</div>";

  html += '<div class="grid cols-2" style="margin-top:16px">';
  html += '<div class="card"><h2>📚 Core Subjects <span class="pill muted">included in GPA</span></h2>';
  if (!mainCourses.length) html += '<div class="empty">No courses classified as GPA-relevant yet. Change a course\u2019s classification on its detail page or in Settings keywords.</div>';
  mainCourses.forEach(x => html += courseCard(x));
  html += "</div>";
  html += '<div class="card"><h2>📖 Other Courses <span class="pill muted">kept visible, excluded from GPA</span></h2>';
  if (!otherCourses.length) html += '<div class="empty">None.</div>';
  otherCourses.forEach(x => html += courseCard(x));
  html += "</div></div>";

  html += '<div class="card" style="margin-top:16px"><h2>📊 All Courses <span class="pill muted">' + courses.length + " courses · click a column to sort</span></h2>";
  html += '<div style="margin-bottom:10px">Filter: ' +
    ["all|All", "main|GPA subjects", "other|Other", "attention|Needs attention", "ungraded|Ungraded work", "failed|Failed scan"]
      .map(o => { const kv = o.split("|"); return '<label class="inline"><input type="radio" name="filter" value="' + kv[0] + '" ' + (filterKey === kv[0] ? "checked" : "") + ">" + kv[1] + "</label>"; }).join("") +
    "</div>";
  html += allCoursesTable(derived);
  html += "</div>";

  html += gpaCalculatorHtml(derived, gpa);
  html += targetGpaHtml(gpaVal, tgn);

  html += '<div class="card" style="margin-top:16px"><h2>📈 Trends</h2>';
  if (!prevGpaEntry) {
    html += '<div class="empty">No previous scan available. Scan again later to see GPA and course trends.</div>';
  } else {
    if (prevGpaEntry.gpa != null && gpaVal != null) {
      const delta = Math.round((gpaVal - prevGpaEntry.gpa) * 100) / 100;
      html += '<div class="kv"><span>Previous GPA</span><b>' + fNum(prevGpaEntry.gpa) + "</b></div>";
      html += '<div class="kv"><span>Current GPA</span><b>' + fNum(gpaVal) + "</b></div>";
      html += '<div class="kv"><span>Change</span><b>' + (delta >= 0 ? "+" : "") + fNum(delta) + "</b></div>";
    }
    const trendRows = [];
    derived.forEach(x => {
      if (x.d.prevPct != null && x.d.pct != null && Math.abs(x.d.pct - x.d.prevPct) >= 0.05) {
        trendRows.push("<tr><td>" + esc(x.c.name) + '</td><td class="num">' + fPct(x.d.prevPct) + " → " + fPct(x.d.pct) + "</td><td>" + (x.d.pct >= x.d.prevPct ? "▲" : "▼") + "</td></tr>");
      }
    });
    if (trendRows.length) html += "<table><thead><tr><th>Course</th><th class=\"num\">Change</th><th></th></tr></thead><tbody>" + trendRows.join("") + "</tbody></table>";
    else html += '<div class="empty">No notable course changes since the previous scan.</div>';
  }
  html += "</div>";

  html += '<div class="grid cols-2" style="margin-top:16px">';
  html += '<div class="card"><h2>Scan History <button id="clear-history" style="float:right;font-size:11px;padding:4px 10px">Clear history</button></h2>';
  html += '<div class="kv"><span>Last scan</span><b>' + fmtDate(lastScan.timestamp) + "</b></div>";
  html += '<div class="kv"><span>Previous scan</span><b>' + (prevScan ? fmtDate(prevScan.timestamp) : "—") + "</b></div>";
  if (history.length) {
    html += '<table style="margin-top:8px"><thead><tr><th>When</th><th class="num">Discovered</th><th class="num">OK</th><th class="num">Failed</th><th class="num">GPA</th></tr></thead><tbody>';
    history.slice().reverse().slice(0, 10).forEach(hh => {
      html += "<tr><td>" + fmtDate(hh.timestamp) + '</td><td class="num">' + hh.discovered + '</td><td class="num">' + hh.succeeded + '</td><td class="num">' + hh.failed + '</td><td class="num">' + (hh.gpa != null ? fNum(hh.gpa) : "—") + "</td></tr>";
    });
    html += "</tbody></table>";
  }
  html += "</div>";
  html += '<div class="card"><h2>Scan Diagnostics</h2>';
  html += '<div class="kv"><span>Course pages visited</span><b>' + ((lastScan.pagesVisited || []).length) + "</b></div>";
  html += '<div class="kv"><span>Courses discovered</span><b>' + lastScan.discovered + "</b></div>";
  html += '<div class="kv"><span>Duplicates removed</span><b>' + (lastScan.duplicatesRemoved || 0) + "</b></div>";
  html += '<div class="kv"><span>Scanned</span><b>' + (lastScan.succeeded + lastScan.failed) + " / " + lastScan.discovered + "</b></div>";
  html += '<div class="kv"><span>Succeeded</span><b>' + lastScan.succeeded + "</b></div>";
  html += '<div class="kv"><span>Empty GradeBooks</span><b>' + (lastScan.empty || 0) + "</b></div>";
  html += '<div class="kv"><span>Failed</span><b>' + lastScan.failed + "</b></div>";
  html += '<div class="muted" style="margin-top:8px">Parser: every course is scanned with <b>ivy-gradebook</b> (trace: detected: ivy → matched: ivy → selected: ivy-gradebook → invoked: ivy-gradebook). There is no generic fallback — if the Ivy parser extracts 0 records the course is marked Failed, never silently re-parsed.</div>';
  html += "</div></div>";

  const failedList = derived.filter(x => x.c.status === "failed" || x.c.status === "empty");
  html += '<div class="card" style="margin-top:16px"><h2>🔍 Scan Details &amp; Errors</h2>';
  if (!failedList.length) html += '<div class="empty">No failed or empty courses in the last scan.</div>';
  failedList.forEach(x => {
    html += "<details><summary>" + (x.c.status === "failed" ? "❌" : "📭") + " " + esc(x.c.name) + " — " + stateOf(x.c) + "</summary>";
    html += '<div class="kv"><span>Course ID</span><b>' + esc(x.c.id) + "</b></div>";
    html += '<div class="kv"><span>GradeBook URL</span><b style="word-break:break-all">' + esc(x.c.gradebookUrl || "") + "</b></div>";
    html += '<div class="kv"><span>Parser</span><b>' + esc(x.c.parserId || "ivy-gradebook") + "</b></div>";
    html += '<div class="kv"><span>Reason</span><b>' + esc(x.c.error || x.c.note || "—") + "</b></div>";
    html += '<div class="kv"><span>Course URL</span><b style="word-break:break-all">' + esc(x.c.url || "") + "</b></div>";
    html += '<div class="kv"><span>Strategy</span><b>' + esc(x.c.strategy || "—") + "</b></div>";
    html += '<div class="kv"><span>Parser trace</span><b>' + esc(x.c.parserTrace || "—") + "</b></div>";
    if ((x.c.warnings || []).length) html += '<div class="kv"><span>Warnings</span><b>' + esc(x.c.warnings.join(" · ")) + "</b></div>";
    if (x.c.diagnostics) html += "<pre>" + esc(JSON.stringify(x.c.diagnostics, null, 1)) + "</pre>";
    html += "</details>";
  });
  html += "</div>";

  main.innerHTML = html;

  bindStudentInfo();
  bindQuarterControls(courses);
  document.getElementById("clear-history").addEventListener("click", async () => {
    await store.set({ gdScanHistory: [] });
    refresh();
  });
  document.querySelectorAll("input[name=filter]").forEach(r => r.addEventListener("change", e => { filterKey = e.target.value; renderOverview(); }));
  bindTableSort();
  bindCalculator();
  document.querySelectorAll("tr.clickable").forEach(tr => tr.addEventListener("click", () => { location.hash = "#/course/" + tr.dataset.id; }));
}

function gpaCalculatorHtml(derived, gpa) {
  const mainRows = derived.filter(x => x.d.cls === "main");
  const excluded = derived.filter(x => !x.d.included);
  let h = '<div class="card" style="margin-top:16px"><h2>🧮 GPA Calculator <span class="pill muted">GPA Track calculated value — not an official Ivy GPA</span></h2>';
  h += '<div class="calc-row"><label class="inline">Scale max <input type="number" id="calc-scale" step="0.1" min="1" style="width:70px" value="' + esc(settings.scaleMax) + '"></label>' +
    '<label class="inline">Weighting <select id="calc-weighting"><option value="equal"' + (settings.equalWeights ? " selected" : "") + '>Equal weighting</option><option value="credits"' + (settings.equalWeights ? "" : " selected") + ">Credits / weights</option></select></label></div>";
  h += '<div class="grid cols-2" style="margin-top:10px"><div>' +
    kvRow("Current calculated GPA", gpa ? fNum(gpa.weighted) : "—") +
    kvRow("Weighted GPA (by credits)", gpa ? fNum(gpa.weighted) + (settings.equalWeights ? " (equal weights active)" : "") : "—") +
    kvRow("Unweighted GPA (simple average)", gpa ? fNum(gpa.unweighted) : "—") +
    kvRow("Courses included", gpa ? gpa.included : 0) +
    kvRow("Courses excluded", excluded.length) +
    kvRow("Total credits / weights", gpa ? fNum(gpa.totalWeight) : "—") + "</div>" +
    '<div class="muted">Points come from the letter → GPA mapping in Settings (a configurable default, not Ivy policy). Letters provided by the LMS are used as-is; percentages are converted with your bands and marked as GPA Track estimates. Courses without a grade are not counted.</div></div>';
  h += '<table style="margin-top:10px"><thead><tr><th>Include</th><th>Course</th><th class="num">%</th><th>Letter</th><th class="num">Points</th><th class="num">Credits</th><th>Source</th></tr></thead><tbody>';
  if (!mainRows.length) h += '<tr><td colspan="7" class="empty">No GPA-relevant courses yet. Mark courses as Main on their detail page.</td></tr>';
  mainRows.forEach(x => {
    h += '<tr><td><input type="checkbox" class="calc-incl" data-id="' + esc(x.c.id) + '"' + (settings.excluded[x.c.id] ? "" : " checked") + "></td>" +
      "<td>" + esc(x.c.name) + '</td><td class="num">' + fPct(x.d.pct) + "</td><td>" + esc(x.d.letter || "—") + "</td>" +
      '<td class="num">' + (x.d.points != null ? fNum(x.d.points) : "—") + "</td>" +
      '<td class="num"><input type="number" class="calc-credit" data-id="' + esc(x.c.id) + '" min="0" step="0.5" style="width:64px" value="' + esc(settings.weights[x.c.id] || 1) + '"' + (settings.equalWeights ? " disabled" : "") + "></td>" +
      '<td class="muted">' + esc(x.d.letterSource || "No grade — not counted") + "</td></tr>";
  });
  h += "</tbody></table>";
  if (excluded.length) h += '<div class="muted" style="margin-top:6px">Not in GPA: ' + esc(excluded.map(x => x.c.name).join(", ")) + "</div>";
  return h + "</div>";
}

function targetGpaHtml(gpaVal, tgn) {
  let h = '<div class="card" style="margin-top:16px"><h2>🎯 Target GPA / What Do I Need?</h2>';
  h += '<div class="calc-row"><label class="inline">Target GPA <input type="number" id="target-gpa" step="0.01" min="0" style="width:80px" value="' + esc(settings.targetGpa) + '"></label></div>';
  h += kvRow("Current GPA (calculated)", gpaVal != null ? fNum(gpaVal) : "—");
  h += kvRow("Target GPA", fNum(settings.targetGpa));
  h += kvRow("Difference", gpaVal != null ? (gpaVal - settings.targetGpa >= 0 ? "+" : "") + fNum(gpaVal - settings.targetGpa) : "—");
  if (tgn && tgn.needed != null) {
    h += '<div class="alert ' + (tgn.needed > settings.scaleMax ? "red" : "blue") + '" style="margin-top:10px">Average GPA needed in GPA-relevant courses that have no grade yet (' + esc(tgn.remainingNames.join(", ")) + "): <b>≈ " + fNum(tgn.needed) + "</b>" +
      (tgn.needed > settings.scaleMax ? " — above the scale maximum, so the target is not reachable with these courses alone." : "") + " GPA Track estimate.</div>";
  } else {
    h += '<div class="muted" style="margin-top:10px">Not enough information for a required-average estimate (it needs both graded and not-yet-graded GPA-relevant courses). GPA Track does not invent a result. Use each course’s “What do I need?” calculator for per-course targets.</div>';
  }
  return h + "</div>";
}

function bindCalculator() {
  const save = async () => { await store.set({ gdSettings: settings }); refresh(); };
  const sc = document.getElementById("calc-scale");
  if (sc) sc.addEventListener("change", e => { settings.scaleMax = Number(e.target.value) || 4; save(); });
  const wt = document.getElementById("calc-weighting");
  if (wt) wt.addEventListener("change", e => { settings.equalWeights = e.target.value === "equal"; save(); });
  const tg = document.getElementById("target-gpa");
  if (tg) tg.addEventListener("change", e => { settings.targetGpa = Number(e.target.value) || 0; save(); });
  document.querySelectorAll(".calc-incl").forEach(el => el.addEventListener("change", e => {
    if (e.target.checked) delete settings.excluded[el.dataset.id]; else settings.excluded[el.dataset.id] = true;
    save();
  }));
  document.querySelectorAll(".calc-credit").forEach(el => el.addEventListener("change", e => {
    settings.weights[el.dataset.id] = Number(e.target.value) || 1;
    save();
  }));
}

function courseCard(x) {
  const c = x.c, d = x.d;
  const statusBadge = d.pct != null || d.letter ? performanceBadge(d.pct, d.letter) : stateBadge(c);
  return '<div class="card course-card" data-id="' + esc(c.id) + '" style="margin-bottom:10px; padding:14px 16px">' +
    '<div class="name">' + esc(c.subject || c.name || "Unknown subject") + (c.section ? ' <span class="muted">— ' + esc(c.section) + '</span>' : '') + "</div>" +
    '<div class="meta">' +
    "<b>" + (d.pct != null ? fPct(d.pct) : "Grade unavailable") + "</b>" +
    (d.letter ? " · " + esc(d.letter) + (d.letterSource === "GPA Track estimate" ? "*" : "") : "") +
    (d.points != null ? " · GPA " + fNum(d.points) : "") +
    " · " + statusBadge +
    (d.ungraded ? " · Ungraded: " + d.ungraded : "") +
    "</div>" +
    (c.status === "empty" ? '<div class="muted" style="margin-top:6px">' + esc(c.note || "No graded items currently available.") + "</div>" : "") +
    (c.status === "failed" ? '<div class="muted" style="margin-top:6px; color:var(--red)">' + esc(c.error || "") + "</div>" : "") +
    '<div style="margin-top:8px"><a href="#/course/' + esc(c.id) + '">View tickets & details →</a></div>' +
    "</div>";
}

function allCoursesTable(derived) {
  let rows = derived.slice();
  if (filterKey === "main") rows = rows.filter(x => x.d.cls === "main");
  if (filterKey === "other") rows = rows.filter(x => x.d.cls !== "main");
  if (filterKey === "attention") rows = rows.filter(x => x.d.cls === "main" && x.d.pct != null && x.d.pct < settings.minPercent);
  if (filterKey === "ungraded") rows = rows.filter(x => x.d.ungraded > 0);
  if (filterKey === "failed") rows = rows.filter(x => x.c.status === "failed");

  const keys = {
    name: x => (x.c.subject || x.c.name || "").toLowerCase(),
    grade: x => x.d.pct == null ? -1 : x.d.pct,
    gpa: x => x.d.points == null ? -1 : x.d.points,
    status: x => stateOf(x.c)
  };
  const k = keys[sortKey] || keys.name;
  rows.sort((a, b) => {
    const va = k(a), vb = k(b);
    return (va < vb ? -1 : va > vb ? 1 : 0) * sortDir;
  });

  const arrow = s => sortKey === s ? (sortDir === 1 ? " ▲" : " ▼") : "";
  let html = "<table><thead><tr>" +
    '<th data-sort="name">Subject' + arrow("name") + "</th>" +
    '<th class="num" data-sort="grade">%' + arrow("grade") + "</th>" +
    "<th>Letter</th><th class=\"num\" data-sort=\"gpa\">GPA" + arrow("gpa") + "</th>" +
    "<th>Weight</th><th class=\"num\">Graded</th><th class=\"num\">Ungraded</th>" +
    '<th data-sort="status">Status' + arrow("status") + "</th>" +
    "<th>GPA class</th></tr></thead><tbody>";
  if (!rows.length) html += '<tr><td colspan="9" class="empty">No courses match this filter.</td></tr>';
  rows.forEach(x => {
    const d = x.d, c = x.c;
    html += '<tr class="clickable" data-id="' + esc(c.id) + '">' +
      "<td><b>" + esc(c.name) + "</b></td>" +
      '<td class="num">' + fPct(d.pct) + "</td>" +
      "<td>" + (d.letter ? esc(d.letter) + (d.letterSource === "GPA Track estimate" ? "*" : "") : "—") + "</td>" +
      '<td class="num">' + (d.points != null ? fNum(d.points) : "—") + "</td>" +
      '<td class="num">' + d.weight + (d.weightKind === "equal" ? "" : " (custom)") + "</td>" +
      '<td class="num">' + d.graded + "</td>" +
      '<td class="num">' + (d.ungraded ? '<span style="color:var(--yellow)">' + d.ungraded + "</span>" : "0") + "</td>" +
      "<td>" + stateBadge(c) + "</td>" +
      '<td><span class="muted">' + esc(d.clsLabel) + "</span></td>" +
      "</tr>";
  });
  html += '</tbody></table><div class="muted" style="margin-top:6px">* Letter estimated by GPA Track from a percentage. Unmarked letters come from the LMS.</div>';
  return html;
}

function bindTableSort() {
  document.querySelectorAll("th[data-sort]").forEach(th => th.addEventListener("click", () => {
    const k = th.dataset.sort;
    if (sortKey === k) sortDir *= -1; else { sortKey = k; sortDir = 1; }
    renderOverview();
  }));
}

// ============================ COURSE DETAIL ============================
function renderCourse(id) {
  const c = lastScan && (lastScan.courses || []).find(x => x.id === id);
  if (!c) {
    main.innerHTML = '<a class="backlink" href="#">← Back to dashboard</a><div class="card" style="margin-top:14px"><div class="empty">Course not found.</div></div>';
    return;
  }
  const d = derive(c);
  const cl = c.courseLevel || [];

  const parts = courseParts(c);
  const locked = false;
  let html = '<a class="backlink" href="#">← Back to dashboard</a>';
  html += '<div class="card" style="margin-top:14px"><h2>' + esc(parts.subject || c.name) + "</h2>";
  if (parts.section) html += '<div class="sub">Section: ' + esc(parts.section) + '</div>';
  html += '<div class="kv"><span>Subject</span><b>' + esc(parts.subject || "Unknown") + '</b></div>';
  html += '<div class="kv"><span>Section</span><b>' + esc(parts.section || "—") + '</b></div>';
  html += '<div class="kv"><span>Current grade</span><b>' + (d.pct != null ? fPct(d.pct) + ' · ' + performanceLevel(d.pct, d.letter).label : "Current grade unavailable") + "</b></div>";
  html += '<div class="kv"><span>Percentage</span><b>' + fPct(d.pct) + "</b></div>";
  html += '<div class="kv"><span>Letter grade</span><b>' + (d.letter ? esc(d.letter) + " (" + esc(d.letterSource) + ")" : "—") + "</b></div>";
  if (d.pct != null || d.letter) html += '<div class="kv"><span>Performance level</span><b>' + performanceBadge(d.pct, d.letter) + '</b></div>';
  html += '<div class="kv"><span>Grade source</span><b>' + esc(d.gradeLabel ? d.gradeLabel + " — " + d.gradeSource : d.gradeSource) + "</b></div>";
  html += '<div class="kv"><span>GPA relevance</span><b>' + esc(d.clsLabel) + "</b></div>";
  html += '<div class="kv"><span>GPA points</span><b>' + (d.points != null ? fNum(d.points) : "—") + "</b></div>";
  html += '<div class="kv"><span>Course weight</span><b>' + d.weight + (d.weightKind === "equal" ? " (equal weighting)" : " (custom weighting)") + "</b></div>";
  html += '<div class="kv"><span>Included in GPA</span><b>' + (d.included ? "Yes" : "No") + "</b></div>";
  html += '<div class="kv"><span>Graded items</span><b>' + d.graded + "</b></div>";
  html += '<div class="kv"><span>Ungraded items</span><b>' + (d.ungraded ? d.ungraded + " — " + esc(d.ungradedNames.join(", ")) : "0") + "</b></div>";
  html += '<div class="kv"><span>Parser</span><b>' + esc(c.parserId || "—") + "</b></div>";
  html += '<div class="kv"><span>Parser trace</span><b>' + esc(c.parserTrace || "") + "</b></div>";
  html += '<div class="kv"><span>Scan status</span><b>' + stateBadge(c) + "</b></div>";
  html += '<div class="kv"><span>Strategy</span><b>' + esc(c.strategy || "—") + "</b></div>";
  html += '<div class="kv"><span>Course URL</span><b style="word-break:break-all">' + esc(c.url || "") + "</b></div>";
  if (c.timing) html += '<div class="kv"><span>Timing</span><b>' + esc("navigation " + (c.timing.navMs || 0) + " ms · render wait " + (c.timing.renderMs || 0) + " ms · total " + (c.timing.totalMs || 0) + " ms") + "</b></div>";
  if ((c.warnings || []).length) html += '<div class="kv"><span>Warnings</span><b>' + esc(c.warnings.join(" · ")) + "</b></div>";
  if ((c.errors || []).length) html += '<div class="kv"><span>Errors</span><b>' + esc(c.errors.join(" · ")) + "</b></div>";
  html += '<div class="kv"><span>GradeBook URL</span><b style="word-break:break-all">' + esc(c.gradebookUrl || "") + "</b></div>";

  html += '<div class="calc-row">' +
    '<label class="inline">GPA class <select id="cls-select" ' + (locked ? 'disabled' : '') + '><option value="main" ' + (d.cls === "main" ? "selected" : "") + ">Main (GPA)</option><option value=\"other\" " + (d.cls === "other" ? "selected" : "") + ">Other</option></select></label>" +
    '<label class="inline">Weight <input type="number" id="weight-input" min="0" step="0.5" style="width:70px" value="' + (settings.weights[c.id] || 1) + '" ' + (settings.equalWeights ? "disabled" : "") + "></label>" +
    '<label class="inline"><input type="checkbox" id="excluded-check" ' + (settings.excluded[c.id] ? "checked" : "") + (locked ? " disabled" : "") + "> Exclude from GPA</label>" +
    "</div></div>";

  html += '<div class="card" style="margin-top:16px"><h2>Course Summary</h2>';
  html += '<div class="kv"><span>Course</span><b>' + esc(c.displayName || c.name) + '</b></div>';
  html += '<div class="kv"><span>Grade source</span><b>' + esc(d.gradeSource || "Unavailable") + '</b></div>';
  html += '<div class="kv"><span>Graded items</span><b>' + d.graded + '</b></div>';
  html += '<div class="kv"><span>Ungraded items</span><b>' + d.ungraded + '</b></div>';
  html += '<div class="kv"><span>GPA relevance</span><b>' + esc(d.clsLabel) + '</b></div>';
  html += '<div class="kv"><span>GPA points</span><b>' + (d.points != null ? fNum(d.points) : "—") + '</b></div>';
  html += '</div>';

  html += '<div class="card" style="margin-top:16px"><h2>🎯 What do I need?</h2>';
  if (d.pct == null) {
    html += '<div class="empty">Current grade unavailable, so this estimate cannot be made.</div>';
  } else if (!d.ungraded) {
    html += '<div class="empty">No ungraded items in this course, so there is nothing left to project.</div>';
  } else {
    html += '<div class="calc-row">' +
      '<label class="inline">Current <input type="number" id="wni-current" value="' + d.pct + '" style="width:80px">%</label>' +
      '<label class="inline">Graded items <input type="number" id="wni-graded" value="' + d.graded + '" style="width:70px"></label>' +
      '<label class="inline">Remaining items <input type="number" id="wni-remaining" value="' + d.ungraded + '" style="width:70px"></label>' +
      '<label class="inline">Target <input type="number" id="wni-target" value="' + settings.minPercent + '" style="width:80px">%</label>' +
      '<button id="wni-calc">Calculate</button></div><div id="wni-result" class="sub" style="margin-top:10px"></div>' +
      '<div class="muted" style="margin-top:8px">Estimated using equal weighting. This is a GPA Track estimate, not an official LMS calculation.</div>';
  }
  html += "</div>";

  const ta = ticketAnalysis(c);
  html += '<div class="card" style="margin-top:16px"><h2>Performance Details</h2>';
  const taRows = [ta.participation_behavior, ta.assignment_assessment, ta.other];
  taRows.forEach(g => {
    if (g.count || g.missing || g.notStarted) {
      html += '<div class="kv"><span>' + esc(g.label) + '</span><b>' + (g.average != null ? 'Average ' + fPct(g.average) : 'No completed grades') + (g.notStarted ? ' · ' + g.notStarted + ' not started' : '') + (g.missing ? ' · ' + g.missing + ' missing' : '') + '</b></div>';
    }
  });
  const causeItems = gradingItems(c).filter(it => {
    if (isAssessmentItem(it) && (Number(it.score) === 0 || Number(it.percentage) === 0)) return true;
    return it.graded && it.percentage != null && Number(it.percentage) < Number(settings.minPercent);
  });
  if (causeItems.length) {
    html += '<div style="margin-top:12px"><b>Items Affecting Your Grade</b><div class="muted" style="margin:4px 0 8px">These are the items with the biggest effect on the result. A zero is Not started only for assessments; zero participation or portfolio work is graded as Very Bad.</div>';
    html += '<table><thead><tr><th>Ticket / Assessment</th><th>Category</th><th class="num">Grade</th><th>Status</th></tr></thead><tbody>';
    causeItems.forEach(it => {
      const zeroGrade = isAssessmentItem(it) && (Number(it.score) === 0 || Number(it.percentage) === 0);
      const status = zeroGrade ? badge("Not started", "yellow") : performanceBadge(it.percentage, it.letter);
      html += '<tr><td>' + esc(it.name) + '</td><td>' + esc(it.category || (it.categoryGroup === 'participation_behavior' ? 'Participation & Behavior' : it.categoryGroup === 'assignment_assessment' ? 'Assignment / Assessment' : 'Other')) + '</td><td class="num">' + (it.score != null ? esc(it.score + " / " + it.max) : (it.percentage != null ? fPct(it.percentage) : "—")) + '</td><td>' + status + '</td></tr>';
    });
    html += '</tbody></table></div>';
  } else if (d.pct != null && d.pct < settings.minPercent) {
    html += '<div class="muted" style="margin-top:10px">No individual item falls below the selected target, so the course result may be driven by LMS course-level weighting.</div>';
  } else {
    html += '<div class="muted" style="margin-top:10px">No items needing improvement were found at the current target.</div>';
  }
  html += '</div>';

  html += '<div class="card" style="margin-top:16px"><h2>All Grading Items <span class="pill muted">graded first, ungraded second</span></h2>';
  if (c.status === "empty") html += '<div class="empty">' + esc(c.note || "No graded items currently available.") + "</div>";
  const items = gradingItems(c).slice().sort((a, b) => (a.graded === b.graded ? 0 : a.graded ? -1 : 1));
  if (!items.length && c.status === "ok") html += '<div class="empty">No grading items were extracted.</div>';
  if (items.length) {
    html += '<div class="muted" style="margin-bottom:8px">All tickets and grades for this subject are listed below. Assessment types can show <b>Not started</b> at 0; participation and portfolio work use the performance levels instead.</div>';
    html += '<table><thead><tr><th>Item</th><th>Category</th><th class="num">Score</th><th class="num">%</th><th>Letter</th><th>Status</th></tr></thead><tbody>';
    items.forEach(it => {
      const st = itemStatus(it);
      const status = badge(st.label, st.cls);
      html += "<tr><td>" + esc(it.name) + "</td><td>" + esc(it.category || (it.categoryGroup === 'participation_behavior' ? 'Participation & Behavior' : it.categoryGroup === 'assignment_assessment' ? 'Assignment / Assessment' : 'Other')) + "</td>" +
        '<td class="num">' + (it.score != null ? esc(it.score + " / " + it.max) : "—") + "</td>" +
        '<td class="num">' + (it.missing ? "Missing" : (it.percentage != null ? fPct(it.percentage) : "—")) + "</td>" +
        "<td>" + (it.letter || "—") + "</td>" +
        "<td>" + status + "</td></tr>";
    });
    html += "</tbody></table>";
  }
  html += "</div>";

  html += gradeScaleHtml();
  html += '<div class="grid cols-2" style="margin-top:16px">';
  html += '<div class="card"><h2>Course-Level Grades (Total / Overall / Final)</h2>';
  if (!cl.length) html += '<div class="empty">No course-level grade rows found in this GradeBook.</div>';
  cl.forEach(t => html += '<div class="kv"><span>' + esc(t.label) + "</span><b>" +
    (t.score != null ? esc(t.score + "/" + t.max) : "") + (t.percentage != null ? " " + fPct(t.percentage) : "") + (t.letter ? " " + esc(t.letter) : "") + "</b></div>");
  html += "</div>";
  html += '<div class="card"><h2>Parser Diagnostics</h2>';
  if (c.diagnostics) html += "<pre>" + esc(JSON.stringify(c.diagnostics, null, 1)) + "</pre>";
  else html += '<div class="empty">No diagnostics stored for this course.</div>';
  html += "</div></div>";

  main.innerHTML = html;

  const clsEl = document.getElementById("cls-select");
  if (clsEl && !locked) clsEl.addEventListener("change", async e => {
    settings.classOverride[c.id] = e.target.value;
    await store.set({ gdSettings: settings });
    refresh();
  });
  const exEl = document.getElementById("excluded-check");
  if (exEl && !locked) exEl.addEventListener("change", async e => {
    if (e.target.checked) settings.excluded[c.id] = true; else delete settings.excluded[c.id];
    await store.set({ gdSettings: settings });
    refresh();
  });
  const wEl = document.getElementById("weight-input");
  if (wEl && !locked) wEl.addEventListener("change", async e => {
    settings.weights[c.id] = Number(e.target.value) || 1;
    await store.set({ gdSettings: settings });
  });
  const btn = document.getElementById("wni-calc");
  if (btn) btn.addEventListener("click", () => {
    const cur = Number(document.getElementById("wni-current").value);
    const graded = Number(document.getElementById("wni-graded").value);
    const rem = Number(document.getElementById("wni-remaining").value);
    const tgt = Number(document.getElementById("wni-target").value);
    const req = GD.requiredAvg(cur, graded, rem, tgt);
    const out = document.getElementById("wni-result");
    if (req == null) out.innerHTML = "Cannot estimate: insufficient data.";
    else if (req > 100) out.innerHTML = "⚠️ Even a perfect score may not reach " + tgt + "% (required average ≈ " + Math.round(req * 10) / 10 + "%).";
    else out.innerHTML = "To reach <b>" + tgt + "%</b>, average about <b>" + fPct(req) + "</b> on the remaining " + rem + " item(s). Equal-weight estimate.";
  });
}

function showOnboarding() {
  const box=document.getElementById("onboarding"); if(!box || localStorage.getItem("gpaTrackGuideSeen")==="1") return;
  box.innerHTML='<div class="guide-card"><button class="guide-close" id="guide-close">×</button><img class="guide-logo-img" src="icons/icon128.png" alt="GPA Track logo"><h2>Welcome to GPA Track</h2><p>Here is the complete student workflow:</p><ol><li><b>Discover Courses</b> — the first scan detects the total number of courses and shows every course name. No grades are scanned yet.</li><li><b>Select GPA Subjects</b> — choose the subjects you want included in your GPA.</li><li><b>Scan All Grades</b> — this must happen before GPA is shown. It collects the grades for all discovered courses.</li><li><b>View GPA</b> — after the full grade scan finishes, GPA Track shows your GPA summary and details.</li><li><b>Scan GPA Subjects</b> — for later updates, you can scan only the GPA subjects you selected. You can also run Scan All Grades again whenever you want.</li><li><b>Tickets & Details</b> — open a course to view its grade, grading items, tickets, and details.</li><li><b>Print GPA Summary</b> — prints only a clean black-and-white GPA summary that can be saved as a PDF.</li></ol><div class="alert blue">The order is always: <b>Discover Courses → Select GPA Subjects → Scan All Grades → GPA</b>.</div><button class="primary" id="guide-start">Got it — Start</button></div>';
  box.style.display="flex";
  document.getElementById("guide-close").onclick=()=>{localStorage.setItem("gpaTrackGuideSeen","1");box.style.display="none"};
  document.getElementById("guide-start").onclick=()=>{localStorage.setItem("gpaTrackGuideSeen","1");box.style.display="none"};
}

function buildPrintSummary(){
  if(!lastScan || lastScan.discoveryOnly || !allGradesScanned) return alert("Scan All Grades first to create the GPA summary.");
  const courses=lastScan.courses||[], derived=courses.map(c=>({c,d:derive(c)})), gpa=GD.computeGpa(courses,settings);
  const selected=derived.filter(x=>x.d.included);
  const el=document.getElementById("print-summary");
  el.innerHTML='<div class="print-title">GPA Track — GPA Summary</div><div class="print-meta">Quarter '+settings.activeQuarter+' · '+new Date(lastScan.timestamp).toLocaleDateString()+'</div><div class="print-gpa">GPA: '+(gpa?fNum(gpa.weighted):'—')+' / '+fNum(settings.scaleMax)+'</div><div class="print-line">GPA Subjects: '+selected.length+'</div><table><thead><tr><th>Subject</th><th>Grade</th><th>Letter</th><th>GPA</th></tr></thead><tbody>'+selected.map(x=>'<tr><td>'+esc(x.c.name)+'</td><td>'+fPct(x.d.pct)+'</td><td>'+esc(x.d.letter||'—')+'</td><td>'+(x.d.points!=null?fNum(x.d.points):'—')+'</td></tr>').join('')+'</tbody></table><div class="print-footer">Generated by GPA Track. This is a calculated student summary.</div>';
  window.print();
}

// ============================ HEADER / PROGRESS ============================
document.getElementById("btn-scan").addEventListener("click", () => chrome.runtime.sendMessage({ type: "GD_START_SCAN" }));
document.getElementById("btn-scan-gpa").addEventListener("click", async () => {
  const q=activeQuarterKey(); const ids=Array.isArray(settings.selectedGpaSubjects[q])?settings.selectedGpaSubjects[q]:[];
  if(!ids.length) return alert("Select your GPA subjects first.");
  chrome.runtime.sendMessage({type:"GD_SCAN_GPA_SUBJECTS",ids});
});
document.getElementById("btn-scan-all").addEventListener("click", () => chrome.runtime.sendMessage({type:"GD_SCAN_ALL_GRADES"}));
document.getElementById("btn-cancel").addEventListener("click", () => chrome.runtime.sendMessage({ type: "GD_CANCEL" }));
document.getElementById("btn-settings").addEventListener("click", () => chrome.tabs.create({ url: "options.html" }));
document.getElementById("btn-print").addEventListener("click", buildPrintSummary);
document.getElementById("btn-retry").addEventListener("click", () => chrome.runtime.sendMessage({ type: "GD_RETRY_FAILED" }));

function updateBanner() {
  const b = document.getElementById("progress-banner");
  const scanning = scanningPhase(progress);
  document.getElementById("btn-scan").disabled = !!scanning;
  document.getElementById("btn-scan-gpa").disabled = !!scanning;
  document.getElementById("btn-scan-all").disabled = !!scanning;
  document.getElementById("btn-cancel").style.display = scanning ? "inline-block" : "none";
  document.getElementById("btn-scan").style.display = discoveryComplete ? "none" : "inline-block";
  document.getElementById("btn-scan-gpa").style.display = (discoveryComplete && allGradesScanned) ? "inline-block" : "none";
  document.getElementById("btn-scan-all").style.display = discoveryComplete ? "inline-block" : "none";
  const n = v => (v == null ? "…" : v);
  if (scanning) {
    b.style.display = "block";
    b.innerHTML = "<b>" + (!discoveryComplete ? "Discovering courses..." : (!allGradesScanned ? "Scanning all grades..." : "Updating grades...")) + "</b>" +
      '<div class="counts-strip" style="margin-top:6px"><span>Discovered: <b>' + n(progress.discovered) + "</b></span>" +
      "<span>Scanned: <b>" + (progress.scanned || 0) + "/" + n(progress.total) + "</b></span>" +
      "<span>Succeeded: <b>" + (progress.succeeded || 0) + "</b></span>" +
      "<span>Failed: <b>" + (progress.failed || 0) + "</b></span></div>" +
      (progress.current ? "<div>Current course: <b>" + esc(progress.current) + "</b></div>" : "") +
      (progress.step ? "<div>Current step: <b>" + esc(progress.step) + "</b></div>" : "") +
      (progress.coursePage ? "<div>Course page: <b>" + progress.coursePage + " / " + n(progress.totalPages) + "</b></div>" : "");
  } else if (progress && progress.error) {
    b.style.display = "block";
    b.textContent = "Scan error: " + progress.error;
  } else if (lastScan) {
    b.style.display = "block";
    b.innerHTML = '<div class="counts-strip"><span>Discovered: <b>' + lastScan.discovered + "</b></span>" +
      "<span>Scanned: <b>" + (lastScan.succeeded + lastScan.failed) + "/" + lastScan.discovered + "</b></span>" +
      "<span>Succeeded: <b>" + lastScan.succeeded + "</b></span>" +
      "<span>Failed: <b>" + lastScan.failed + "</b></span>" +
      '<span class="muted">Last scan ' + esc(fmtDate(lastScan.timestamp)) + " · " + ((lastScan.pagesVisited || []).length) + " course page(s)</span></div>";
  } else {
    b.style.display = "none";
  }
}

chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === "GD_PROGRESS") { progress = msg.progress; updateBanner(); if (!scanningPhase(progress)) refresh(); }
});

setInterval(async () => {
  const st = await store.get("gdProgress");
  const incoming = st.gdProgress || null;
  const changed = JSON.stringify(incoming || {}) !== JSON.stringify(progress || {});
  progress = incoming;
  updateBanner();
  if (changed && !scanningPhase(progress)) refresh();
}, 1500);

refresh();
})();
