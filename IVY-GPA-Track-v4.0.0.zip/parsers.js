(function () {
"use strict";
// Parser registry. Priority: LMS-specific parsers first, generic ONLY when no supported LMS is detected.
// When a supported LMS (Ivy) is detected, the generic parser is never allowed to run.
var GRADEBOOK_RE = /\/courses\/[^/]+\/gradingitemslist/;

function genericParse() {
  var d = { parserId: "generic", strategy: "generic-table-scan", tableCount: 0, tablesScanned: 0, candidateRows: 0, acceptedRows: 0, gradeSamples: [], warnings: ["Generic parser: used only when no supported LMS is detected"], errors: [] };
  var items = [];
  Array.prototype.slice.call(document.querySelectorAll("table")).forEach(function (t) {
    d.tableCount++; d.tablesScanned++;
    Array.prototype.slice.call(t.querySelectorAll("tr")).forEach(function (r) {
      d.candidateRows++;
      var m = null, name = null;
      Array.prototype.slice.call(r.querySelectorAll("td")).forEach(function (c) {
        var x = (c.textContent || "").trim();
        var mm = x.match(/^(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/);
        if (mm && !m) m = mm; else if (!name && /[A-Za-z]{2,}/.test(x)) name = x;
      });
      if (m && name && Number(m[2]) > 0) {
        d.acceptedRows++;
        items.push({ name: name, category: null, score: +m[1], max: +m[2], percentage: Math.round(m[1] / m[2] * 1000) / 10, letter: null, graded: true });
      }
    });
  });
  return { items: items, courseLevel: [], diagnostics: d };
}

var REGISTRY = [
  {
    id: "ivy-gradebook", lms: "ivy", priority: 1,
    detect: function () { return /(^|\.)ivyis\.org$/i.test(location.hostname); },
    matches: function () { return GRADEBOOK_RE.test(location.pathname); },
    parse: function () { return window.IvyParser.parse(); }
  },
  {
    id: "generic", lms: "generic", priority: 99,
    detect: function () { return true; },
    matches: function () { return true; },
    parse: function () { return genericParse(); }
  }
];

function traceText(t) {
  if (!t) return "";
  return "detected: " + t.detected + " | matched: " + t.matched + " | selected: " + t.selected + " | invoked: " + t.invoked;
}

function select() {
  var trace = { detected: null, matched: null, selected: null, invoked: null, genericAllowed: false, candidates: [], reason: "" };
  var specific = REGISTRY.filter(function (p) { return p.lms !== "generic"; }).sort(function (a, b) { return a.priority - b.priority; });
  REGISTRY.forEach(function (p) {
    var det = !!p.detect();
    trace.candidates.push({ id: p.id, priority: p.priority, detected: det, matched: det && !!p.matches() });
  });
  var detected = specific.filter(function (p) { return p.detect(); });
  if (detected.length) {
    trace.detected = detected[0].lms;
    var matched = detected.filter(function (p) { return p.matches(); });
    if (!matched.length) {
      trace.matched = "none"; trace.selected = "none"; trace.invoked = "none";
      trace.reason = "LMS '" + trace.detected + "' detected but no parser supports " + location.pathname + "; generic fallback is disabled for supported LMS";
      return { parser: null, trace: trace };
    }
    trace.matched = matched[0].lms;
    trace.selected = matched[0].id;
    trace.reason = "LMS-specific parser selected (priority " + matched[0].priority + "); generic fallback disabled";
    return { parser: matched[0], trace: trace };
  }
  var generic = REGISTRY.filter(function (p) { return p.lms === "generic"; })[0];
  trace.detected = "none"; trace.matched = "generic"; trace.selected = "generic"; trace.genericAllowed = true;
  trace.reason = "No supported LMS detected";
  return { parser: generic, trace: trace };
}

function run() {
  var s = select();
  if (!s.parser) return { ok: false, error: s.trace.reason, trace: s.trace };
  var res = s.parser.parse();
  s.trace.invoked = res && res.diagnostics ? res.diagnostics.parserId : "unknown";
  if (s.trace.invoked !== s.trace.selected) {
    return { ok: false, error: "Parser mismatch: selected " + s.trace.selected + " but " + s.trace.invoked + " ran", trace: s.trace };
  }
  res.diagnostics.parserSelection = s.trace;
  return { ok: true, result: res, trace: s.trace };
}

window.GDParsers = { registry: REGISTRY, select: select, run: run, traceText: traceText };
})();
